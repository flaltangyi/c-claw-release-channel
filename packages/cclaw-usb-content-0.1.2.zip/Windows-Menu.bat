@echo off
setlocal EnableExtensions EnableDelayedExpansion
title C-CLAW Advanced Menu

set "UCLAW_DIR=%~dp0"
for %%I in ("%~dp0.") do set "UCLAW_PS_ROOT=%%~fI"
set "APP_DIR=%UCLAW_DIR%app"
set "CORE_DIR=%APP_DIR%\core"
set "DATA_DIR=%UCLAW_DIR%data"
set "STATE_DIR=%DATA_DIR%\.openclaw"
set "NODE_DIR=%UCLAW_DIR%app\runtime\node-win-x64"
set "NODE_BIN=%NODE_DIR%\node.exe"
set "NPM_BIN=%NODE_DIR%\npm.cmd"
set "OPENCLAW_MJS=%CORE_DIR%\node_modules\openclaw\openclaw.mjs"
set "MODEL_DIR=%UCLAW_DIR%models"
set "LLAMA_SERVER=%UCLAW_DIR%local-model\llama.cpp\llama-server.exe"
set "START_HERMES_LOCAL=%UCLAW_DIR%Start-Hermes-Local.bat"
set "START_OPENCLAW_HERMES=%UCLAW_DIR%Start-OpenClaw-Hermes.bat"
set "CONFIG_PAGE=%UCLAW_DIR%Config.html"
set "DIAG_SCRIPT=%UCLAW_DIR%Windows-Diagnose.bat"
set "REPAIR_SCRIPT=%UCLAW_DIR%support\Repair-OpenClawGateway.ps1"
set "SUPPORT_SCRIPT=%UCLAW_DIR%Windows-Support.bat"
set "VERSION_PAGE=%UCLAW_DIR%Version.html"
set "ROLLBACK_SCRIPT=%UCLAW_DIR%update\Rollback-CClaw.ps1"
set "LOG_DIR=%DATA_DIR%\logs"
set "BACKUP_DIR=%DATA_DIR%\backups"
set "PATH=%NODE_DIR%;%PATH%"

set "OPENCLAW_HOME=%DATA_DIR%"
set "OPENCLAW_STATE_DIR=%STATE_DIR%"
set "OPENCLAW_CONFIG_PATH=%STATE_DIR%\openclaw.json"
set "C_CLAW_LOCAL_ONLY=1"

if exist "%APP_DIR%\core-win" if not exist "%APP_DIR%\core" ren "%APP_DIR%\core-win" core
if not exist "%DATA_DIR%" mkdir "%DATA_DIR%"
if not exist "%STATE_DIR%" mkdir "%STATE_DIR%"
if not exist "%DATA_DIR%\memory" mkdir "%DATA_DIR%\memory"
if not exist "%BACKUP_DIR%" mkdir "%BACKUP_DIR%"
if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"

:menu
cls
echo.
echo   ========================================
echo     C-CLAW Advanced Menu
echo     Local Hermes USB
echo     First batch: Windows local Hermes USB
echo   ========================================
echo   First-time customers should close this menu and double-click:
echo   Start-OpenClaw-Hermes.bat
echo.
call :status
echo.
echo   Quick actions:
echo   [A] Start local Hermes model
echo   [B] Open config center
echo   [C] Run health check
echo   [D] Repair stale OpenClaw gateway
echo   [E] Create support bundle
echo   [F] Open version page
echo.
echo   Maintenance:
echo   [1] Start OpenClaw assistant
echo   [2] Backup config
echo   [3] Restore config backup
echo   [4] View logs
echo   [5] License status
echo   [6] Roll back previous update
echo   [7] Open release notes
echo   [8] System info
echo.
echo   [0] Exit
echo.
set /p choice="  Choose [A-F/0-8]: "

if /i "%choice%"=="A" goto :start_hermes
if /i "%choice%"=="B" goto :open_config
if /i "%choice%"=="C" goto :diagnose
if /i "%choice%"=="D" goto :repair
if /i "%choice%"=="E" goto :support
if /i "%choice%"=="F" goto :version
if "%choice%"=="1" goto :start_openclaw
if "%choice%"=="2" goto :backup
if "%choice%"=="3" goto :restore
if "%choice%"=="4" goto :logs
if "%choice%"=="5" goto :license
if "%choice%"=="6" goto :rollback
if "%choice%"=="7" goto :release_notes
if "%choice%"=="8" goto :sysinfo
if "%choice%"=="0" exit /b 0

echo.
echo   Invalid choice.
pause
goto :menu

:status
if exist "%NODE_BIN%" (
    for /f "usebackq delims=" %%v in (`"%NODE_BIN%" --version 2^>nul`) do echo   Node: %%v
) else (
    echo   Node: missing
)
set "CCLAW_VERSION=unknown"
if exist "%UCLAW_DIR%C-CLAW_VERSION" (
    for /f "usebackq delims=" %%v in ("%UCLAW_DIR%C-CLAW_VERSION") do set "CCLAW_VERSION=%%v"
)
echo   C-CLAW_VERSION: !CCLAW_VERSION!
set "OPENCLAW_VER=unknown"
if exist "%UCLAW_DIR%OPENCLAW_VERSION" (
    for /f "usebackq delims=" %%v in ("%UCLAW_DIR%OPENCLAW_VERSION") do set "OPENCLAW_VER=%%v"
)
echo   OPENCLAW_VERSION: !OPENCLAW_VER!
set "UPDATE_SOURCE_STATUS=missing"
if exist "%UCLAW_DIR%update-source.txt" (
    findstr /i /c:"stable.json" "%UCLAW_DIR%update-source.txt" >nul 2>&1
    if not errorlevel 1 (
        set "UPDATE_SOURCE_STATUS=stable manifest"
    ) else (
        set "UPDATE_SOURCE_STATUS=custom or offline"
    )
)
echo   Update source: !UPDATE_SOURCE_STATUS!
if exist "%STATE_DIR%\openclaw.json" (
    findstr /i /c:"hermes-local" /c:"11435" "%STATE_DIR%\openclaw.json" >nul 2>&1
    if not errorlevel 1 (
        echo   Config: local Hermes
    ) else (
        echo   Config: exists, local Hermes not confirmed
    )
) else (
    echo   Config: not created
)
set "MODEL_FILE="
for /f "delims=" %%m in ('dir /b /a-d "%MODEL_DIR%\Hermes-*.gguf" 2^>nul') do (
    if not defined MODEL_FILE set "MODEL_FILE=%%m"
)
if defined MODEL_FILE (
    echo   Hermes GGUF: !MODEL_FILE!
) else (
    echo   Hermes GGUF: missing Hermes gguf
)
if exist "%LLAMA_SERVER%" (
    echo   llama-server: ready
) else (
    echo   llama-server: missing
)
goto :eof

:start_hermes
echo.
echo   Starting local Hermes model...
if exist "%START_HERMES_LOCAL%" (
    start "" "%START_HERMES_LOCAL%"
) else (
    echo   Missing Start-Hermes-Local.bat
    pause
)
goto :menu

:open_config
echo.
echo   Opening config center...
if exist "%CONFIG_PAGE%" (
    start "" "%CONFIG_PAGE%"
) else (
    echo   Missing Config.html
    pause
)
goto :menu

:diagnose
echo.
echo   Running health check...
if exist "%DIAG_SCRIPT%" (
    call "%DIAG_SCRIPT%"
) else (
    echo   Missing Windows-Diagnose.bat
    pause
)
goto :menu

:repair
echo.
echo   Repairing stale OpenClaw gateway for this USB only...
if exist "%REPAIR_SCRIPT%" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%REPAIR_SCRIPT%" -UsbRoot "%UCLAW_PS_ROOT%" -NoOpenBrowser
    set "REPAIR_EXIT=%ERRORLEVEL%"
    echo.
    echo   Repair exit code: !REPAIR_EXIT!
    if "!REPAIR_EXIT!"=="10" echo   Existing gateway looks healthy.
    if "!REPAIR_EXIT!"=="0" echo   Repair check finished.
) else (
    echo   Missing Repair-OpenClawGateway.ps1
)
pause
goto :menu

:support
echo.
echo   Creating support bundle...
if exist "%SUPPORT_SCRIPT%" (
    call "%SUPPORT_SCRIPT%"
) else (
    echo   Missing Windows-Support.bat
    pause
)
goto :menu

:version
if exist "%VERSION_PAGE%" (
    start "" "%VERSION_PAGE%"
) else (
    echo   Missing Version.html
    pause
)
goto :menu

:start_openclaw
echo.
echo   Starting OpenClaw assistant...
if exist "%START_OPENCLAW_HERMES%" (
    start "" "%START_OPENCLAW_HERMES%"
) else if exist "%UCLAW_DIR%Windows-Start.bat" (
    start "" "%UCLAW_DIR%Windows-Start.bat"
) else (
    echo   Missing OpenClaw startup script.
    pause
)
goto :menu

:backup
echo.
echo   Creating config backup...
set "BK=%BACKUP_DIR%\backup-%date:~0,4%%date:~5,2%%date:~8,2%-%time:~0,2%%time:~3,2%%time:~6,2%"
set "BK=%BK: =0%"
mkdir "%BK%" >nul 2>&1
if exist "%STATE_DIR%\openclaw.json" copy "%STATE_DIR%\openclaw.json" "%BK%\openclaw.json" >nul
if exist "%DATA_DIR%\config.json" copy "%DATA_DIR%\config.json" "%BK%\config.json" >nul
echo   Backup saved: %BK%
pause
goto :menu

:restore
echo.
echo   Restore config backup
echo.
if not exist "%BACKUP_DIR%" (
    echo   No backup directory found.
    pause
    goto :menu
)
dir /b /ad "%BACKUP_DIR%\backup-*" 2>nul
echo.
set /p bkname="  Backup folder name: "
if "%bkname%"=="" goto :menu
if exist "%BACKUP_DIR%\%bkname%\openclaw.json" (
    copy "%BACKUP_DIR%\%bkname%\openclaw.json" "%STATE_DIR%\openclaw.json" >nul
    echo   Restored openclaw.json.
) else (
    echo   Backup does not contain openclaw.json.
)
pause
goto :menu

:logs
echo.
echo   Recent logs
echo.
if not exist "%LOG_DIR%" (
    echo   No log directory found.
    pause
    goto :menu
)
dir /b /o-d "%LOG_DIR%" 2>nul
echo.
echo   Open data/logs for full files.
pause
goto :menu

:license
if exist "%UCLAW_DIR%Check-License.bat" (
    call "%UCLAW_DIR%Check-License.bat"
) else (
    echo   Missing Check-License.bat
    pause
)
goto :menu

:rollback
echo.
echo   Running rollback tool...
if exist "%ROLLBACK_SCRIPT%" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%ROLLBACK_SCRIPT%" -UsbRoot "%UCLAW_PS_ROOT%"
) else (
    echo   Missing rollback script.
)
pause
goto :menu

:release_notes
if exist "%UCLAW_DIR%Release-Notes.html" (
    start "" "%UCLAW_DIR%Release-Notes.html"
) else (
    echo   Missing Release-Notes.html
    pause
)
goto :menu

:sysinfo
echo.
echo   Root: %UCLAW_DIR%
echo   Data: %DATA_DIR%
echo   Model port: 11435
echo   Config port: 18788
echo   Gateway ports: 18789-18799
echo.
if exist "%NODE_BIN%" "%NODE_BIN%" --version
if exist "%OPENCLAW_MJS%" echo   OpenClaw runtime: installed
if exist "%MODEL_DIR%" dir /b "%MODEL_DIR%\Hermes-*.gguf" 2>nul
pause
goto :menu
