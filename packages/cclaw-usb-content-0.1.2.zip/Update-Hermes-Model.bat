@echo off
title C-CLAW - Update Hermes Model (Manual)

set "UCLAW_DIR=%~dp0"
for %%I in ("%~dp0.") do set "USB_ROOT=%%~fI"
set "SCRIPT=%~dp0update\Update-HermesModel.ps1"

echo.
echo   ========================================
echo     C-CLAW Hermes Model Manual Upgrade
echo   ========================================
echo.
echo   Manual only: this updates the local Hermes GGUF model, not the shell package.
echo   The model is about 5GB. Confirm the network and disk space first.
echo   Run it only when the model hash changed or support tells you to.
echo   Small C-CLAW upgrades will not auto-download the model.
echo   This keeps the shell version and model upgrade path separate.
echo.

if not exist "%SCRIPT%" (
    echo   [ERROR] Missing Hermes model update script:
    echo   %SCRIPT%
    echo.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -UsbRoot "%USB_ROOT%"
if errorlevel 1 (
    echo.
    echo   [FAILED] Hermes model update did not complete. Contact support and provide the support package.
)

echo.
pause
