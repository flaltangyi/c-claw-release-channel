@echo off
title C-CLAW - Update Shell

set "UCLAW_DIR=%~dp0"
for %%I in ("%~dp0.") do set "USB_ROOT=%%~fI"
set "SCRIPT=%~dp0update\Update-CClaw.ps1"

echo.
echo   ========================================
echo     C-CLAW Small Shell Update
echo   ========================================
echo.
echo   This updates the C-CLAW shell only.
echo   It reads the stable manifest and keeps the local Hermes model unchanged.
echo   Use this for small program updates. If only the Hermes hash changed,
echo   run Update-Hermes-Model.bat instead.
echo.

if not exist "%SCRIPT%" (
    echo   [ERROR] Missing update script:
    echo   %SCRIPT%
    echo.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -UsbRoot "%USB_ROOT%"
if errorlevel 1 (
    echo.
    echo   [FAILED] Shell update did not complete. Contact support and provide the support package.
)

echo.
pause
