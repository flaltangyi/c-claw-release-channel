@echo off
title C-CLAW - Start Local Assistant

set "UCLAW_DIR=%~dp0"
for %%I in ("%~dp0.") do set "UCLAW_PS_ROOT=%%~fI"
set "STARTUP_LOG=%UCLAW_DIR%data\logs\startup-openclaw-hermes.log"
if not exist "%UCLAW_DIR%data\logs" mkdir "%UCLAW_DIR%data\logs" >nul 2>&1
>>"%STARTUP_LOG%" echo.
>>"%STARTUP_LOG%" echo ==== Start-OpenClaw-Hermes %DATE% %TIME% ====

echo   Opening the C-CLAW waiting page...
>>"%STARTUP_LOG%" echo Opening launch page
start "" "%UCLAW_DIR%C-CLAW-Launch.html"

echo.
echo   ========================================
echo     C-CLAW Local Assistant
echo   ========================================
echo.
echo   Normal customer path:
echo   1. Keep all black windows open.
echo   2. Wait while the local Hermes model loads.
echo   3. The browser will enter the local assistant when ready.
echo.
echo   Do not type the 18789 address or search for a gateway token.
echo   If startup fails, run Windows-Diagnose.bat first, then Windows-Support.bat.
echo.

set "LICENSE_SCRIPT=%UCLAW_DIR%license\Show-CClawLicense.ps1"
if exist "%LICENSE_SCRIPT%" (
    >>"%STARTUP_LOG%" echo Checking license
    powershell -NoProfile -ExecutionPolicy Bypass -File "%LICENSE_SCRIPT%" -UsbRoot "%UCLAW_PS_ROOT%" -Quiet
    if errorlevel 1 (
        echo.
        echo   [WARN] License is missing or invalid. Local startup will continue,
        echo          but official updates, model downloads, and support require a valid license.
        echo.
    )
)

>>"%STARTUP_LOG%" echo Configuring Hermes local model
call "%UCLAW_DIR%Configure-Hermes-Local.bat"
if errorlevel 1 exit /b 1

echo   Opening the local Hermes model window...
>>"%STARTUP_LOG%" echo Starting Hermes window
start "C-CLAW Hermes Local Model" cmd /k ""%UCLAW_DIR%Start-Hermes-Assistant.bat""

echo.
echo   The local model is starting in its own window.
echo   C-CLAW will start now. The waiting page will enter chat when ready.
>>"%STARTUP_LOG%" echo Continuing without blocking on Hermes readiness

echo.
echo   Starting the local assistant service...
>>"%STARTUP_LOG%" echo Calling Windows-Start.bat
set "C_CLAW_ALLOW_MODEL_LOADING=1"
call "%UCLAW_DIR%Windows-Start.bat"
>>"%STARTUP_LOG%" echo Windows-Start.bat returned errorlevel %ERRORLEVEL%
