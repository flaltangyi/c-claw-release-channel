﻿param(
    [Parameter(Mandatory = $true)]
    [string]$UClawDir
)

$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8
$UClawDir = (Resolve-Path -LiteralPath $UClawDir).Path
$DataDir = Join-Path $UClawDir "data"
$StateDir = Join-Path $DataDir ".openclaw"
$LogDir = Join-Path $DataDir "logs"
$SupportRoot = Join-Path $DataDir "support"
$ArchiveRoot = Join-Path $SupportRoot "archive"
$NodeBin = Join-Path $UClawDir "app\runtime\node-win-x64\node.exe"
$CoreDir = Join-Path $UClawDir "app\core"
$OpenClawMjs = Join-Path $CoreDir "node_modules\openclaw\openclaw.mjs"
$LicenseHelperPath = Join-Path $UClawDir "license\CClaw-License.ps1"
$SupportLogTailLines = 200
$MaxSupportLogTailLength = 20000

New-Item -ItemType Directory -Force -Path $SupportRoot | Out-Null
New-Item -ItemType Directory -Force -Path $ArchiveRoot | Out-Null
$GeneratedAt = Get-Date
$Timestamp = $GeneratedAt.ToString("yyyyMMdd-HHmmss")

function New-ShortHash {
    param([string]$Text)

    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
        $hashBytes = $sha.ComputeHash($bytes)
        return -join ($hashBytes[0..3] | ForEach-Object { $_.ToString("x2") }).ToUpperInvariant()
    } finally {
        $sha.Dispose()
    }
}

function New-SupportId {
    param(
        [string]$Root,
        [datetime]$GeneratedAt
    )

    $seed = "$Root|$env:COMPUTERNAME|$env:USERNAME|$($GeneratedAt.ToString('o'))"
    $baseId = "CCLAW-SUP-$($GeneratedAt.ToString('yyyyMMdd-HHmmss'))-$(New-ShortHash -Text $seed)"
    $candidate = $baseId
    $counter = 2
    while (Test-Path -LiteralPath (Join-Path $ArchiveRoot $candidate)) {
        $candidate = "{0}-{1:D2}" -f $baseId, $counter
        $counter++
    }
    return $candidate
}

$SupportId = New-SupportId -Root $UClawDir -GeneratedAt $GeneratedAt
$SupportArchiveDir = Join-Path $ArchiveRoot $SupportId
$BundleDir = Join-Path $SupportArchiveDir "bundle"
New-Item -ItemType Directory -Force -Path $BundleDir | Out-Null
$ManifestPath = Join-Path $SupportArchiveDir "manifest.json"
$ZipPath = Join-Path $SupportArchiveDir "$SupportId.zip"
$CustomerZipPath = Join-Path $SupportRoot "support-bundle-$Timestamp.zip"
$CustomerZipCounter = 2
while (Test-Path -LiteralPath $CustomerZipPath) {
    $CustomerZipPath = Join-Path $SupportRoot ("support-bundle-$Timestamp-{0:D2}.zip" -f $CustomerZipCounter)
    $CustomerZipCounter++
}

function Write-TextFile {
    param([string]$Path, [string[]]$Lines)
    $Lines | ForEach-Object { Redact-SecretText ([string]$_) } | Set-Content -LiteralPath $Path -Encoding UTF8
}

function Append-CommandOutput {
    param([string]$Path, [scriptblock]$Command)
    try {
        Redact-SecretText (& $Command 2>&1 | Out-String) | Add-Content -LiteralPath $Path -Encoding UTF8
    } catch {
        Redact-SecretText "ERROR: $($_.Exception.Message)" | Add-Content -LiteralPath $Path -Encoding UTF8
    }
}

function Limit-TextLength {
    param(
        [string]$Text,
        [int]$MaxLength = 20000
    )

    if ([string]::IsNullOrEmpty($Text) -or $Text.Length -le $MaxLength) {
        return $Text
    }

    $prefixLength = [Math]::Max(0, $MaxLength - 3)
    return $Text.Substring(0, $prefixLength) + '...'
}

function Redact-SecretText {
    param([string]$Text)

    $value = [string]$Text
    $value = $value -replace '(?i)(Authorization\s*:\s*)(Bearer|Basic)?\s*[A-Za-z0-9._\-+/=:]+', '$1***REDACTED***'
    $value = $value -replace '(?i)\bBearer\s+[A-Za-z0-9._\-+/=]+', 'Bearer ***REDACTED***'
    $value = $value -replace '(?i)\bBasic\s+[A-Za-z0-9._\-+/=]+', 'Basic ***REDACTED***'
    $value = $value -replace '\bsk-[A-Za-z0-9_-]{8,}\b', 'sk-***REDACTED***'
    $value = $value -replace '(?i)\b(?:license[_ -]?key|licenseKey|serial[_ -]?number)\b\s*[:=]\s*["'']?[^"''\r\n,;&|]+["'']?', 'licenseKey=***REDACTED***'
    $value = $value -replace '(?i)(\b(?:api[_-]?key|key|token|secret|password|app[_-]?secret|client[_-]?secret|access[_-]?token|refresh[_-]?token|authorization|license[_-]?key|licenseKey)\b\s*[:=]\s*)["'']?[^"''\s,;&|]+["'']?', '$1***REDACTED***'
    $value = $value -replace '(?i)"((?:apiKey|token|secret|password|appSecret|clientSecret|accessToken|refreshToken|authorization|licenseKey))"\s*:\s*"[^"]*"', '"$1":"***REDACTED***"'
    $value = $value -replace '(?i)([?&](?:api[_-]?key|token|secret|password|access[_-]?token|refresh[_-]?token|license[_-]?key)=)[^&\s]+', '$1***REDACTED***'
    $value = $value -replace '\b1[3-9]\d{9}\b', '***PHONE_REDACTED***'
    $value = $value -replace '(?i)\b[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}\b', '***EMAIL_REDACTED***'
    return $value
}

function Redact-JsonText {
    param([string]$Text)

    return Redact-SecretText $Text
}

function Get-RedactedFile {
    param(
        [string]$Path,
        [int]$MaxLength = 20000,
        [string]$NotFoundMessage = 'file not found'
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        return $NotFoundMessage
    }

    $rawText = Get-Content -LiteralPath $Path -Raw -Encoding UTF8
    $redacted = Redact-SecretText $rawText
    return Limit-TextLength -Text $redacted -MaxLength $MaxLength
}

function Get-RedactedTail {
    param(
        [string]$Path,
        [int]$TailLines = 200,
        [int]$MaxLength = 20000
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        return "gateway.log not found"
    }

    $rawTail = Get-Content -LiteralPath $Path -Tail $TailLines -Encoding UTF8 | Out-String
    $redacted = Redact-SecretText $rawTail
    return Limit-TextLength -Text $redacted -MaxLength $MaxLength
}

Write-Host "[1/8] Collecting system info..."
$summaryPath = Join-Path $BundleDir "support-summary.txt"
Write-TextFile $summaryPath @(
    "C-CLAW Support Bundle",
    "SupportId: $SupportId",
    "Generated: $($GeneratedAt.ToString('o'))",
    "UCLAW_DIR: $UClawDir",
    "COMPUTERNAME: $env:COMPUTERNAME",
    "USERNAME: $env:USERNAME",
    ""
)

$systemPath = Join-Path $BundleDir "system-info.txt"
Write-TextFile $systemPath @("System Info", "===========", "")
Append-CommandOutput $systemPath { Get-ComputerInfo | Select-Object OsName, OsVersion, OsArchitecture, CsManufacturer, CsModel, CsTotalPhysicalMemory }
Append-CommandOutput $systemPath { Get-Volume | Select-Object DriveLetter, FileSystemLabel, FileSystem, SizeRemaining, Size }

Write-Host "[2/8] Checking runtime..."
$runtimePath = Join-Path $BundleDir "runtime-check.txt"
$runtimeLines = @(
    "Runtime Check",
    "=============",
    "NODE_BIN=$NodeBin",
    "CORE_DIR=$CoreDir",
    "OPENCLAW_MJS=$OpenClawMjs",
    ""
)
if (Test-Path -LiteralPath $NodeBin) {
    $runtimeLines += "NODE_EXISTS"
    $runtimeLines += (& $NodeBin --version 2>&1 | Out-String).Trim()
} else {
    $runtimeLines += "MISSING_NODE"
}
if (Test-Path -LiteralPath $CoreDir) { $runtimeLines += "CORE_EXISTS" } else { $runtimeLines += "MISSING_CORE" }
if (Test-Path -LiteralPath $OpenClawMjs) {
    $runtimeLines += "OPENCLAW_MJS_EXISTS"
    if (Test-Path -LiteralPath $NodeBin) {
        $runtimeLines += (& $NodeBin $OpenClawMjs --version 2>&1 | Out-String).Trim()
    }
} else {
    $runtimeLines += "MISSING_OPENCLAW_MJS"
}
Write-TextFile $runtimePath $runtimeLines

Write-Host "[3/8] Checking ports and processes..."
$processPath = Join-Path $BundleDir "processes.txt"
Write-TextFile $processPath @("Port And Process Check", "======================", "")
Append-CommandOutput $processPath {
    Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
        Where-Object { $_.LocalPort -ge 18789 -and $_.LocalPort -le 18799 } |
        Select-Object LocalAddress, LocalPort, OwningProcess
}
Append-CommandOutput $processPath {
    Get-Process node -ErrorAction SilentlyContinue |
        Select-Object Id, ProcessName, Path, StartTime
}

Write-Host "[4/8] Redacting config..."
$configPath = Join-Path $StateDir "openclaw.json"
$sanitizedConfigPath = Join-Path $BundleDir "openclaw.sanitized.json"
if (Test-Path -LiteralPath $configPath) {
    $raw = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8
    Redact-JsonText $raw | Set-Content -LiteralPath $sanitizedConfigPath -Encoding UTF8
} else {
    "Config not found" | Set-Content -LiteralPath $sanitizedConfigPath -Encoding UTF8
}

Write-Host "[5/8] Checking license..."
$licenseStatusPath = Join-Path $BundleDir "license-status.txt"
$licenseManifest = [ordered]@{
    status = "UNKNOWN"
    licenseId = $null
    edition = $null
    channel = $null
    supportUntil = $null
    supportActive = $null
}
if (Test-Path -LiteralPath $LicenseHelperPath) {
    try {
        . $LicenseHelperPath
        $license = Test-CClawLicense -UsbRoot $UClawDir
        $licenseManifest.status = [string]$license.Status
        $licenseManifest.licenseId = [string]$license.LicenseId
        $licenseManifest.edition = [string]$license.Edition
        $licenseManifest.channel = [string]$license.Channel
        $licenseManifest.supportUntil = [string]$license.SupportUntil
        $licenseManifest.supportActive = [bool]$license.SupportActive
        Write-TextFile $licenseStatusPath @(
            "License Status",
            "==============",
            "Status: $($license.Status)",
            "Message: $($license.Message)",
            "LicenseId: $($license.LicenseId)",
            "Edition: $($license.Edition)",
            "Channel: $($license.Channel)",
            "IssuedAt: $($license.IssuedAt)",
            "SupportUntil: $($license.SupportUntil)",
            "SupportActive: $($license.SupportActive)",
            "UpdatesUntil: $($license.UpdatesUntil)",
            "UpdatesActive: $($license.UpdatesActive)",
            "Features: $($license.Features -join ', ')",
            "LicensePath: $($license.LicensePath)"
        )
    } catch {
        $licenseManifest.status = "ERROR"
        Write-TextFile $licenseStatusPath @("License Status", "==============", "ERROR: $($_.Exception.Message)")
    }
} else {
    $licenseManifest.status = "HELPER_NOT_FOUND"
    Write-TextFile $licenseStatusPath @("License Status", "==============", "License helper not found: $LicenseHelperPath")
}

Write-Host "[6/8] Copying diagnostic and log tails..."
$diagnosticPath = Join-Path $UClawDir "diagnostic-log.txt"
if (Test-Path -LiteralPath $diagnosticPath) {
    Get-RedactedFile -Path $diagnosticPath -MaxLength $MaxSupportLogTailLength |
        Set-Content -LiteralPath (Join-Path $BundleDir "diagnostic-log.txt") -Encoding UTF8
}
$gatewayLog = Join-Path $LogDir "gateway.log"
$gatewayTail = Join-Path $BundleDir "gateway-log-tail.txt"
Get-RedactedTail -Path $gatewayLog -TailLines $SupportLogTailLines -MaxLength $MaxSupportLogTailLength |
    Set-Content -LiteralPath $gatewayTail -Encoding UTF8

foreach ($openClawLogName in @("openclaw-gateway.out.log", "openclaw-gateway.err.log")) {
    $openClawLog = Join-Path $LogDir $openClawLogName
    $openClawTail = Join-Path $BundleDir "$openClawLogName-tail.txt"
    Get-RedactedTail -Path $openClawLog -TailLines $SupportLogTailLines -MaxLength $MaxSupportLogTailLength |
        Set-Content -LiteralPath $openClawTail -Encoding UTF8
}

Write-Host "[7/8] Checking network..."
$networkPath = Join-Path $BundleDir "network-check.txt"
Write-TextFile $networkPath @("Network Check", "=============", "")
if ($env:C_CLAW_SUPPORT_BUNDLE_ENABLE_ONLINE -eq "1" -and $env:C_CLAW_SUPPORT_BUNDLE_SKIP_ONLINE -ne "1") {
    $urls = @(
        "https://registry.npmmirror.com/openclaw/latest",
        "https://api.u-claw.org/v1/models",
        "https://api.deepseek.com"
    )
    foreach ($url in $urls) {
        try {
            $res = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 8
            "$url -> HTTP $($res.StatusCode)" | Add-Content -LiteralPath $networkPath -Encoding UTF8
        } catch {
            "$url -> FAILED $($_.Exception.Message)" | Add-Content -LiteralPath $networkPath -Encoding UTF8
        }
    }
} else {
    "Skipped online checks by default. Set C_CLAW_SUPPORT_BUNDLE_ENABLE_ONLINE=1 for an explicit operator-run network check." | Add-Content -LiteralPath $networkPath -Encoding UTF8
}

Write-Host "[8/8] Creating manifest and zip..."
$bundleFiles = Get-ChildItem -LiteralPath $BundleDir -File -Recurse | Sort-Object FullName
$manifestFiles = @(
    foreach ($file in $bundleFiles) {
        $relativePath = $file.FullName.Substring($BundleDir.Length).TrimStart('\', '/')
        [ordered]@{
            path = $relativePath
            sizeBytes = $file.Length
            sha256 = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        }
    }
)

$manifest = [ordered]@{
    supportId = $SupportId
    generatedAt = $GeneratedAt.ToString("o")
    archivePath = $SupportArchiveDir
    bundlePath = $BundleDir
    zipPath = $ZipPath
    uclawDir = $UClawDir
    tool = "Collect-SupportBundle.ps1"
    schemaVersion = 1
    redaction = [ordered]@{
        enabled = $true
        covers = @("api key", "token", "secret", "password", "license key", "Authorization", "Bearer", "Basic", "phone", "email")
    }
    license = $licenseManifest
    files = $manifestFiles
}

$manifestJson = $manifest | ConvertTo-Json -Depth 8
Redact-SecretText $manifestJson | Set-Content -LiteralPath $ManifestPath -Encoding UTF8

if (Test-Path -LiteralPath $ZipPath) { Remove-Item -LiteralPath $ZipPath -Force }
Compress-Archive -Path (Join-Path $BundleDir "*") -DestinationPath $ZipPath -Force
Copy-Item -LiteralPath $ZipPath -Destination $CustomerZipPath -Force

$zipHash = (Get-FileHash -LiteralPath $ZipPath -Algorithm SHA256).Hash.ToLowerInvariant()
$manifest.zipSha256 = $zipHash
$manifest.zipSizeBytes = (Get-Item -LiteralPath $ZipPath).Length
$manifest.customerZipPath = $CustomerZipPath
$manifest.customerZipSha256 = (Get-FileHash -LiteralPath $CustomerZipPath -Algorithm SHA256).Hash.ToLowerInvariant()
$manifest.customerZipSizeBytes = (Get-Item -LiteralPath $CustomerZipPath).Length
$finalManifestJson = $manifest | ConvertTo-Json -Depth 8
Redact-SecretText $finalManifestJson | Set-Content -LiteralPath $ManifestPath -Encoding UTF8

Write-Host ""
Write-Host "========================================"
Write-Host "售后支持包已生成"
Write-Host "========================================"
Write-Host "SupportId: $SupportId"
Write-Host "Archive: $SupportArchiveDir"
Write-Host "ZIP: $ZipPath"
Write-Host "客户可发送 ZIP: $CustomerZipPath"
Write-Host "Manifest: $ManifestPath"
Write-Host ""
Write-Host "请把客户可发送 ZIP、订单号、报错截图一起发给客服。"
Write-Host "支持包会尽量隐藏 API Key，请不要单独发送支付密码、网页登录密码或模型 API Key。"
