@echo off
title C-CLAW - Update Hermes Model

set "UCLAW_DIR=%~dp0"
for %%I in ("%~dp0.") do set "USB_ROOT=%%~fI"
set "SCRIPT=%~dp0update\Update-HermesModel.ps1"

echo.
echo   ========================================
echo     C-CLAW Hermes Model Update
echo   ========================================
echo.
echo   Manual only: this updates the local Hermes model, not the shell package.
echo   Run it only when the local model needs a refresh or support tells you to.
echo   The file is large. Confirm the network and disk space first.
echo   Small C-CLAW upgrades will not auto-download the model.
echo.

if not exist "%SCRIPT%" (
    echo   [ERROR] Missing Hermes model update script:
    echo   %SCRIPT%
    echo.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -UsbRoot "%USB_ROOT%"
if errorlevel 1 (
    echo.
    echo   [FAILED] Hermes model update did not complete. Contact support and provide the support package.
)

echo.
pause
