@echo off
title C-CLAW - Hermes Local Model Service (Test Only)
setlocal EnableDelayedExpansion

set "UCLAW_DIR=%~dp0"
set "MODEL_DIR=%UCLAW_DIR%models"
set "LLAMA_DIR=%UCLAW_DIR%local-model\llama.cpp"
set "LLAMA_SERVER=%LLAMA_DIR%\llama-server.exe"
set "MODEL_PATH="
if not defined HERMES_CONTEXT_TOKENS set "HERMES_CONTEXT_TOKENS=8192"

echo.
echo   ========================================
echo     C-CLAW Hermes Local Model Service
echo   ========================================
echo.
if "%C_CLAW_ASSISTANT_LAUNCH%"=="1" (
    echo   This window is the required local Hermes model service.
    echo   Keep it open while using the OpenClaw assistant.
) else (
    echo   This path starts only the local llama.cpp model service.
    echo   It is a model diagnostic entry, not the final OpenClaw assistant.
    echo   If you want the assistant, close this window and run Start-OpenClaw-Hermes.bat.
)
echo.

if not exist "%LLAMA_SERVER%" (
    echo   [ERROR] Missing llama-server.exe
    echo   Expected: %LLAMA_SERVER%
    echo.
    echo   Please make sure the USB preparation has finished.
    pause
    exit /b 1
)

for %%f in ("%MODEL_DIR%\*Hermes*Q4*.gguf") do (
    if not defined MODEL_PATH if exist "%%~ff" set "MODEL_PATH=%%~ff"
)
if not defined MODEL_PATH (
    for %%f in ("%MODEL_DIR%\*.gguf") do (
        if not defined MODEL_PATH if exist "%%~ff" set "MODEL_PATH=%%~ff"
    )
)

if not defined MODEL_PATH (
    echo   [ERROR] Missing GGUF model file.
    echo   Expected folder: %MODEL_DIR%
    echo.
    echo   Put the Hermes Q4 .gguf file into the models folder.
    pause
    exit /b 1
)

echo   Checking existing Hermes service on port 11435...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$root=[IO.Path]::GetFullPath('%UCLAW_DIR%').TrimEnd([char[]]@('\','/')).ToLowerInvariant(); $conn=Get-NetTCPConnection -LocalPort 11435 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1; if(-not $conn){ exit 0 }; $ownerPid=[int]$conn.OwningProcess; $proc=Get-CimInstance Win32_Process -Filter ('ProcessId = ' + $ownerPid) -ErrorAction SilentlyContinue; $cmd=([string]$proc.CommandLine).ToLowerInvariant(); if($cmd.Contains($root)){ try { Invoke-WebRequest -UseBasicParsing -Uri 'http://127.0.0.1:11435/v1/models' -TimeoutSec 5 | Out-Null; Write-Host '  [OK] Existing Hermes service is healthy. Reusing it.'; exit 10 } catch { Write-Host '  [FIX] Existing Hermes service is stale. Stopping it.'; Stop-Process -Id $ownerPid -Force -ErrorAction SilentlyContinue; exit 0 } } else { Write-Host '  [ERROR] Port 11435 is used by another program.'; Write-Host ('        PID ' + $ownerPid + ': ' + $proc.CommandLine); exit 20 }"
if "%ERRORLEVEL%"=="10" (
    echo.
    echo   Hermes local model service is already running.
    echo   You can close this extra window and continue using OpenClaw.
    pause
    exit /b 0
)
if "%ERRORLEVEL%"=="20" (
    echo.
    echo   Please close the program using port 11435, then run this file again.
    pause
    exit /b 1
)

echo   Model file: !MODEL_PATH!
echo   Endpoint: http://127.0.0.1:11435/v1
echo   Context: !HERMES_CONTEXT_TOKENS! tokens
echo.
echo   First load may take 1-3 minutes. Keep this window open.
echo.

"%LLAMA_SERVER%" -m "!MODEL_PATH!" --host 127.0.0.1 --port 11435 --alias hermes-local -c !HERMES_CONTEXT_TOKENS! -np 1 -ngl 0

echo.
echo   Hermes local model service stopped.
pause
