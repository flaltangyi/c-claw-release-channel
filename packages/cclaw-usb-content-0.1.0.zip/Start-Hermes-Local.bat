@echo off
title C-CLAW - Hermes Local Model Service (Test Only)
setlocal EnableDelayedExpansion

set "UCLAW_DIR=%~dp0"
set "MODEL_DIR=%UCLAW_DIR%models"
set "LLAMA_DIR=%UCLAW_DIR%local-model\llama.cpp"
set "LLAMA_SERVER=%LLAMA_DIR%\llama-server.exe"
set "MODEL_PATH="
if not defined HERMES_CONTEXT_TOKENS set "HERMES_CONTEXT_TOKENS=8192"

echo.
echo   ========================================
echo     C-CLAW Hermes Local Model Service
echo   ========================================
echo.
echo   This path only starts the local llama.cpp service.
echo   It is a model test page, not the final OpenClaw assistant entry.
echo   If you want the assistant, close this window and run Start-OpenClaw-Hermes.bat.
echo.

if not exist "%LLAMA_SERVER%" (
    echo   [ERROR] Missing llama-server.exe
    echo   Expected: %LLAMA_SERVER%
    echo.
    echo   Please make sure the USB preparation has finished.
    pause
    exit /b 1
)

for %%f in ("%MODEL_DIR%\*Hermes*Q4*.gguf") do (
    if not defined MODEL_PATH if exist "%%~ff" set "MODEL_PATH=%%~ff"
)
if not defined MODEL_PATH (
    for %%f in ("%MODEL_DIR%\*.gguf") do (
        if not defined MODEL_PATH if exist "%%~ff" set "MODEL_PATH=%%~ff"
    )
)

if not defined MODEL_PATH (
    echo   [ERROR] Missing GGUF model file.
    echo   Expected folder: %MODEL_DIR%
    echo.
    echo   Put the Hermes Q4 .gguf file into the models folder.
    pause
    exit /b 1
)

echo   Model file: !MODEL_PATH!
echo   Endpoint: http://127.0.0.1:11435/v1
echo   Context: !HERMES_CONTEXT_TOKENS! tokens
echo.
echo   First load may take 1-3 minutes. Keep this window open.
echo.

"%LLAMA_SERVER%" -m "!MODEL_PATH!" --host 127.0.0.1 --port 11435 --alias hermes-local -c !HERMES_CONTEXT_TOKENS! -np 1 -ngl 0

echo.
echo   Hermes local model service stopped.
pause
