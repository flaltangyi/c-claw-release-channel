#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=portable/Linux-Support.sh
source "$SCRIPT_DIR/Linux-Support.sh"

uclaw_prepare_linux_runtime

model_path="$(uclaw_find_model)" || {
    printf '[ERROR] Missing GGUF model in %s\n' "$MODEL_DIR" >&2
    exit 1
}

uclaw_require_executable "$NODE_BIN" "Node.js runtime"
uclaw_require_executable "$LLAMA_SERVER" "llama.cpp server"
uclaw_require_file "$UCLAW_DIR/lib/configure-hermes-local.mjs" "Hermes config helper"
uclaw_require_file "$UCLAW_DIR/config-server/server.js" "config server"
uclaw_prepare_openclaw_deps
staged_core_dir="$(uclaw_prepare_openclaw_core_stage)"
export UCLAW_OPENCLAW_CORE_STAGE_DIR="$staged_core_dir"
uclaw_require_file "$(uclaw_openclaw_entry)" "OpenClaw gateway entry"

openclaw_state_dir="$(uclaw_openclaw_state_dir)"
mkdir -p "$openclaw_state_dir/home" "$openclaw_state_dir/cache" "$openclaw_state_dir/config" "$openclaw_state_dir/state" "$openclaw_state_dir/npm-cache"
mkdir -p "$openclaw_state_dir/plugin-runtime-deps"
export HOME="$openclaw_state_dir/home"
export XDG_CACHE_HOME="$openclaw_state_dir/cache"
export XDG_CONFIG_HOME="$openclaw_state_dir/config"
export XDG_STATE_HOME="$openclaw_state_dir/state"
export npm_config_cache="$openclaw_state_dir/npm-cache"
export OPENCLAW_HOME="$openclaw_state_dir/home"
export OPENCLAW_STATE_DIR="$openclaw_state_dir/state"
export OPENCLAW_PLUGIN_STAGE_DIR="$openclaw_state_dir/plugin-runtime-deps"
if [[ "${C_CLAW_ENABLE_PLUGINS:-0}" != "1" ]]; then
    export OPENCLAW_DISABLE_BUNDLED_PLUGINS=1
fi
export OPENCLAW_CONFIG_PATH="$OPENCLAW_CONFIG_PATH"
export UCLAW_APP_ROOT="$UCLAW_DIR"
export PATH="$NODE_TARGET/bin:$PATH"

mkdir -p "$DATA_DIR/logs" "$OPENCLAW_CONFIG_DIR"

printf '\n'
printf '========================================\n'
printf '  C-CLAW OpenClaw Assistant + Hermes (Linux)\n'
printf '========================================\n'
printf '\n'
printf '  This path starts Hermes first, then opens the OpenClaw assistant.\n'
printf '  If you only want to test the local model service, use Start-Hermes-Local.sh.\n'
printf '\n'
printf '  model: %s\n' "$model_path"
printf '  local model endpoint: http://127.0.0.1:%s/v1\n' "$MODEL_PORT"
printf '  staged core: %s\n' "$staged_core_dir"
printf '\n'

uclaw_configure_hermes_local "$NODE_BIN"

config_pid="$(uclaw_start_config_server "$NODE_BIN")"
hermes_pid="$(uclaw_start_hermes_server_bg "$model_path")"

cleanup() {
    local pids=("$config_pid" "$hermes_pid")
    for pid in "${pids[@]}"; do
        if [[ -n "${pid:-}" ]] && kill -0 "$pid" 2>/dev/null; then
            kill "$pid" 2>/dev/null || true
        fi
    done
}
trap cleanup EXIT

printf '  waiting for Hermes /v1/models ...\n'
if ! uclaw_wait_http "$MODEL_ENDPOINT" 180 2; then
    printf '[ERROR] Hermes did not become ready at %s\n' "$MODEL_ENDPOINT" >&2
    exit 1
fi
printf '  Hermes is ready.\n'

gateway_port="$(uclaw_pick_gateway_port)" || {
    printf '[ERROR] No available gateway port in %s-%s\n' "$GATEWAY_PORT_START" "$GATEWAY_PORT_END" >&2
    exit 1
}

gateway_url="http://127.0.0.1:${gateway_port}/#token=uclaw"
config_url="http://127.0.0.1:${CONFIG_SERVER_PORT}/"

uclaw_open_browser_if_available "$gateway_url"
uclaw_open_browser_if_available "$config_url"

printf '\n'
printf '  gateway: %s\n' "$gateway_url"
printf '  config:  %s\n' "$config_url"
printf '\n'
printf '  starting OpenClaw assistant from staged ext4 core ...\n'
printf '\n'

cd "$staged_core_dir"
OPENCLAW_ENTRY="$(uclaw_openclaw_entry)"
"$NODE_BIN" "$OPENCLAW_ENTRY" gateway run --allow-unconfigured --force --port "$gateway_port"
