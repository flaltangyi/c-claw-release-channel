#!/usr/bin/env bash

set -euo pipefail

UCLAW_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_DIR="$UCLAW_DIR/app"
CORE_DIR="$APP_DIR/core"
DATA_DIR="$UCLAW_DIR/data"
MODEL_DIR="$UCLAW_DIR/models"
RUNTIME_DIR="$APP_DIR/runtime"
NODE_VERSION="v22.22.1"
NODE_TARGET="$RUNTIME_DIR/node-linux-x64"
NODE_BIN="$NODE_TARGET/bin/node"
NPM_BIN="$NODE_TARGET/bin/npm"
NODE_ARCHIVE="node-${NODE_VERSION}-linux-x64.tar.xz"
NODE_URL="https://nodejs.org/dist/${NODE_VERSION}/${NODE_ARCHIVE}"
NODE_SHA256="9a6bc82f9b491279147219f6a18add1e18424dce90d41d2a5fcd69d4924ba3aa"
NODE_SHA256_UPPER="9A6BC82F9B491279147219F6A18ADD1E18424DCE90D41D2A5FCD69D4924BA3AA"
NPM_MIRROR="https://registry.npmmirror.com"
LLAMA_TAG="b9145"
LLAMA_TARGET="$UCLAW_DIR/local-model/llama.cpp/linux-x64"
LLAMA_SERVER="$LLAMA_TARGET/llama-server"
LLAMA_ARCHIVE="llama-b9145-bin-ubuntu-x64.tar.gz"
LLAMA_URL="https://github.com/ggml-org/llama.cpp/releases/download/${LLAMA_TAG}/${LLAMA_ARCHIVE}"
OPENCLAW_CONFIG_DIR="$DATA_DIR/.openclaw"
OPENCLAW_CONFIG_PATH="$OPENCLAW_CONFIG_DIR/openclaw.json"
OPENCLAW_RUNTIME_PATH="$OPENCLAW_CONFIG_DIR/runtime.json"
LOCAL_HOME="$DATA_DIR/linux-home"
CONFIG_SERVER_PORT="18788"
GATEWAY_PORT_START="18789"
GATEWAY_PORT_END="18799"
MODEL_ENDPOINT="http://127.0.0.1:11435/v1/models"
MODEL_PORT="11435"

uclaw_runtime_dir() {
    printf '%s\n' "$RUNTIME_DIR"
}

uclaw_node_bin() {
    printf '%s\n' "$NODE_BIN"
}

uclaw_llama_server_bin() {
    printf '%s\n' "$LLAMA_SERVER"
}

uclaw_openclaw_entry() {
    if [[ -n "${UCLAW_OPENCLAW_CORE_STAGE_DIR:-}" ]]; then
        printf '%s\n' "$UCLAW_OPENCLAW_CORE_STAGE_DIR/node_modules/openclaw/openclaw.mjs"
    else
        printf '%s\n' "$CORE_DIR/node_modules/openclaw/openclaw.mjs"
    fi
}

uclaw_hash_text() {
    local text="$1"
    if command -v sha256sum >/dev/null 2>&1; then
        printf '%s' "$text" | sha256sum | awk '{print toupper($1)}'
    else
        printf '%s' "$text" | shasum -a 256 | awk '{print toupper($1)}'
    fi
}

uclaw_trim_file() {
    local path="$1"
    if [[ -f "$path" ]]; then
        tr -d '\r\n' < "$path"
    fi
}

uclaw_linux_cache_root() {
    local candidate=""
    local override="${UCLAW_LINUX_STAGE_ROOT:-}"

    if [[ -n "$override" ]]; then
        candidate="$override"
    elif [[ -n "${XDG_CACHE_HOME:-}" && -d "$(dirname "$XDG_CACHE_HOME")" && -w "$(dirname "$XDG_CACHE_HOME")" && "${XDG_CACHE_HOME}" != /mnt/* && "${XDG_CACHE_HOME}" != /media/* && "${XDG_CACHE_HOME}" != /run/desktop/mnt/host/* ]]; then
        candidate="$XDG_CACHE_HOME/c-claw"
    elif [[ -n "${HOME:-}" && -d "$HOME" && -w "$HOME" && "${HOME}" != /mnt/* && "${HOME}" != /media/* && "${HOME}" != /run/desktop/mnt/host/* ]]; then
        candidate="$HOME/.cache/c-claw"
    else
        candidate="/tmp/c-claw"
    fi

    printf '%s\n' "$candidate"
}

uclaw_realpath_maybe_missing() {
    local path="$1"
    if command -v realpath >/dev/null 2>&1; then
        realpath -m -- "$path"
    elif command -v readlink >/dev/null 2>&1; then
        readlink -m -- "$path"
    else
        printf '%s\n' "$path"
    fi
}

uclaw_assert_safe_stage_path() {
    local path="$1"
    local label="$2"
    local normalized
    local core_real

    if [[ -z "$path" || "$path" != /* ]]; then
        printf '[ERROR] Unsafe %s path: %s\n' "$label" "${path:-<empty>}" >&2
        return 1
    fi

    normalized="$(uclaw_realpath_maybe_missing "$path")"
    core_real="$(uclaw_realpath_maybe_missing "$CORE_DIR")"

    case "$normalized" in
        /|/mnt|/mnt/*|/media|/media/*|/run/desktop/mnt/host|/run/desktop/mnt/host/*|/proc|/proc/*|/sys|/sys/*|/dev|/dev/*|/usr|/usr/*|/bin|/bin/*|/sbin|/sbin/*|/lib|/lib/*|/lib64|/lib64/*|/etc|/etc/*|/var|/var/*)
            printf '[ERROR] Unsafe %s path: %s\n' "$label" "$normalized" >&2
            return 1
            ;;
    esac

    case "$normalized" in
        /home/*|/tmp/*)
            ;;
        *)
            printf '[ERROR] %s path must stay under /home or /tmp ext4 storage: %s\n' "$label" "$normalized" >&2
            return 1
            ;;
    esac

    case "$normalized" in
        "$core_real"|"$core_real"/*)
            printf '[ERROR] %s path must not be inside portable OpenClaw core: %s\n' "$label" "$normalized" >&2
            return 1
            ;;
    esac

    printf '%s\n' "$normalized"
}

uclaw_assert_ext4_stage_path() {
    local path="$1"
    local label="$2"
    local fs_type=""

    if command -v findmnt >/dev/null 2>&1; then
        fs_type="$(findmnt -no FSTYPE --target "$path" 2>/dev/null | head -n 1 | tr -d '[:space:]')"
    fi

    if [[ -z "$fs_type" && "$(uname -s 2>/dev/null)" == "Linux" ]] && command -v stat >/dev/null 2>&1; then
        fs_type="$(stat -f -c %T "$path" 2>/dev/null | tr -d '[:space:]')"
    fi

    case "$fs_type" in
        ext4|ext2/ext3)
            return 0
            ;;
        *)
            printf '[ERROR] %s path must be on Linux ext4 storage. path=%s fs=%s\n' "$label" "$path" "${fs_type:-unknown}" >&2
            return 1
            ;;
    esac
}

uclaw_safe_remove_stage_dir() {
    local path="$1"
    local normalized

    normalized="$(uclaw_assert_safe_stage_path "$path" "stage cleanup")" || return 1
    rm -rf -- "$normalized"
}

uclaw_openclaw_state_dir() {
    printf '%s\n' "$(uclaw_linux_cache_root)/openclaw-state"
}

uclaw_openclaw_core_stage_root() {
    printf '%s\n' "$(uclaw_linux_cache_root)/openclaw-core"
}

uclaw_openclaw_stage_key() {
    local core_package_json="$CORE_DIR/package.json"
    local core_package_lock="$CORE_DIR/package-lock.json"
    local openclaw_package_json="$CORE_DIR/node_modules/openclaw/package.json"
    local seed=""

    uclaw_require_file "$core_package_json" "OpenClaw core package manifest"
    uclaw_require_file "$openclaw_package_json" "OpenClaw package metadata"

    seed="$(uclaw_sha256 "$core_package_json")"
    if [[ -f "$core_package_lock" ]]; then
        seed+=$'\n'"$(uclaw_sha256 "$core_package_lock")"
    else
        seed+=$'\nmissing-package-lock'
    fi
    seed+=$'\n'"$(uclaw_sha256 "$openclaw_package_json")"
    seed+=$'\n'"OPENCLAW_VERSION=$(uclaw_trim_file "$UCLAW_DIR/OPENCLAW_VERSION")"
    seed+=$'\n'"C-CLAW_VERSION=$(uclaw_trim_file "$UCLAW_DIR/C-CLAW_VERSION")"

    uclaw_hash_text "$seed"
}

uclaw_prepare_openclaw_core_stage() {
    local source_entry
    local stage_root
    local stage_key
    local stage_dir
    local stage_marker
    local tmp_dir

    source_entry="$CORE_DIR/node_modules/openclaw/openclaw.mjs"
    uclaw_require_file "$source_entry" "OpenClaw gateway entry"

    stage_root="$(uclaw_assert_safe_stage_path "$(uclaw_openclaw_core_stage_root)" "OpenClaw core stage root")"
    mkdir -p -- "$stage_root"
    stage_root="$(uclaw_assert_safe_stage_path "$stage_root" "OpenClaw core stage root")"
    uclaw_assert_ext4_stage_path "$stage_root" "OpenClaw core stage root"
    stage_key="$(uclaw_openclaw_stage_key)"
    stage_dir="$stage_root/$stage_key"
    stage_marker="$stage_dir/.uclaw-stage-key"
    stage_dir="$(uclaw_assert_safe_stage_path "$stage_dir" "OpenClaw core stage")"

    if [[ -f "$stage_marker" ]] && [[ "$(tr -d '\r\n' < "$stage_marker")" == "$stage_key" ]] && [[ -f "$stage_dir/node_modules/openclaw/openclaw.mjs" ]]; then
        UCLAW_OPENCLAW_CORE_STAGE_DIR="$stage_dir"
        printf 'Using staged OpenClaw core: %s\n' "$stage_dir" >&2
        printf '%s\n' "$stage_dir"
        return 0
    fi

    tmp_dir="$(mktemp -d "$stage_root/.stage.${stage_key}.XXXXXX")"
    tmp_dir="$(uclaw_assert_safe_stage_path "$tmp_dir" "OpenClaw temp stage")"
    uclaw_assert_ext4_stage_path "$tmp_dir" "OpenClaw temp stage"

    printf 'Staging OpenClaw core to ext4 cache...\n' >&2
    printf '  source: %s\n' "$CORE_DIR" >&2
    printf '  target: %s\n' "$stage_dir" >&2
    printf '  this is a one-time copy for the current version hash.\n' >&2

    if command -v rsync >/dev/null 2>&1; then
        printf '  copy: rsync -a\n' >&2
        if ! rsync -a --info=stats1 --human-readable -- "$CORE_DIR"/ "$tmp_dir"/ >&2; then
            uclaw_safe_remove_stage_dir "$tmp_dir" || true
            return 1
        fi
    else
        printf '  copy: tar stream fallback\n' >&2
        if ! (cd "$CORE_DIR" && tar -cf - .) | (cd "$tmp_dir" && tar -xf -); then
            uclaw_safe_remove_stage_dir "$tmp_dir" || true
            return 1
        fi
    fi

    printf '%s\n' "$stage_key" > "$tmp_dir/.uclaw-stage-key"
    uclaw_require_file "$tmp_dir/node_modules/openclaw/openclaw.mjs" "staged OpenClaw gateway entry"
    if [[ -e "$stage_dir" ]]; then
        uclaw_safe_remove_stage_dir "$stage_dir"
    fi
    mv -- "$tmp_dir" "$stage_dir"

    UCLAW_OPENCLAW_CORE_STAGE_DIR="$stage_dir"
    printf 'Staged OpenClaw core ready: %s\n' "$stage_dir" >&2
    printf '%s\n' "$stage_dir"
}

uclaw_find_model() {
    local match
    shopt -s nullglob
    for match in "$MODEL_DIR"/*Hermes*Q4*.gguf "$MODEL_DIR"/*.gguf; do
        if [[ -f "$match" ]]; then
            printf '%s\n' "$match"
            shopt -u nullglob
            return 0
        fi
    done
    shopt -u nullglob
    return 1
}

uclaw_require_file() {
    local path="$1"
    local label="$2"
    if [[ ! -f "$path" ]]; then
        printf '[ERROR] Missing %s: %s\n' "$label" "$path" >&2
        return 1
    fi
}

uclaw_require_executable() {
    local path="$1"
    local label="$2"
    if [[ ! -x "$path" ]]; then
        printf '[ERROR] Missing %s: %s\n' "$label" "$path" >&2
        return 1
    fi
}

uclaw_sha256() {
    local path="$1"
    if command -v sha256sum >/dev/null 2>&1; then
        sha256sum "$path" | awk '{print toupper($1)}'
    else
        shasum -a 256 "$path" | awk '{print toupper($1)}'
    fi
}

uclaw_prepare_node_runtime() {
    local target="$NODE_TARGET"
    local node="$NODE_BIN"
    if [[ -x "$node" ]]; then
        return 0
    fi

    mkdir -p "$target"
    local tmp_tar
    tmp_tar="$(mktemp)"
    trap 'rm -f "$tmp_tar"' RETURN

    printf 'Downloading Node.js %s from official distribution...\n' "$NODE_VERSION"
    curl -fL "$NODE_URL" -o "$tmp_tar"

    local actual_sha
    actual_sha="$(uclaw_sha256 "$tmp_tar")"
    if [[ "$actual_sha" != "$NODE_SHA256_UPPER" ]]; then
        printf '[ERROR] Node.js SHA256 mismatch.\nExpected: %s\nActual:   %s\n' "$NODE_SHA256" "$actual_sha" >&2
        return 1
    fi

    tar -xJf "$tmp_tar" --strip-components=1 -C "$target"
    chmod +x "$node"
    rm -f "$tmp_tar"
    trap - RETURN
}

uclaw_prepare_llama_runtime() {
    local target="$LLAMA_TARGET"
    local server="$LLAMA_SERVER"
    if [[ -x "$server" ]]; then
        return 0
    fi

    mkdir -p "$target"
    local tmp_tar
    tmp_tar="$(mktemp)"
    trap 'rm -f "$tmp_tar"' RETURN

    printf 'Downloading llama.cpp %s Linux x64 runtime...\n' "$LLAMA_TAG"
    curl -fL "$LLAMA_URL" -o "$tmp_tar"
    tar -xzf "$tmp_tar" --strip-components=1 -C "$target"
    chmod +x "$server"
    rm -f "$tmp_tar"
    trap - RETURN
}

uclaw_prepare_linux_runtime() {
    uclaw_prepare_node_runtime
    uclaw_prepare_llama_runtime
}

uclaw_prepare_openclaw_deps() {
    local openclaw_entry
    openclaw_entry="$(uclaw_openclaw_entry)"
    if [[ -f "$openclaw_entry" ]]; then
        return 0
    fi

    mkdir -p "$LOCAL_HOME"
    export HOME="$LOCAL_HOME"
    export XDG_CACHE_HOME="$LOCAL_HOME/.cache"
    export npm_config_cache="$LOCAL_HOME/.npm"
    export PATH="$NODE_TARGET/bin:$PATH"

    uclaw_require_executable "$NODE_BIN" "Node.js runtime"
    uclaw_require_executable "$NPM_BIN" "npm runtime"
    mkdir -p "$CORE_DIR"
    printf 'Installing OpenClaw into %s...\n' "$CORE_DIR"
    "$NODE_BIN" "$NPM_BIN" install --prefix "$CORE_DIR" --registry="$NPM_MIRROR" --no-audit --no-fund
}

uclaw_backup_openclaw_config() {
    mkdir -p "$OPENCLAW_CONFIG_DIR"
    if [[ -f "$OPENCLAW_CONFIG_PATH" ]]; then
        local stamp
        stamp="$(date +%Y%m%d_%H%M%S)"
        cp -f "$OPENCLAW_CONFIG_PATH" "$OPENCLAW_CONFIG_DIR/openclaw.before-hermes.${stamp}.json"
    fi
}

uclaw_configure_hermes_local() {
    local node_bin="$1"
    uclaw_require_executable "$node_bin" "Node.js runtime"
    uclaw_require_file "$UCLAW_DIR/lib/configure-hermes-local.mjs" "Hermes config helper"
    uclaw_backup_openclaw_config
    "$node_bin" "$UCLAW_DIR/lib/configure-hermes-local.mjs" "$OPENCLAW_CONFIG_PATH"
}

uclaw_wait_http() {
    local url="$1"
    local timeout_seconds="${2:-120}"
    local interval_seconds="${3:-2}"
    local deadline=$((SECONDS + timeout_seconds))
    while (( SECONDS < deadline )); do
        if curl -fsS --max-time 2 "$url" >/dev/null 2>&1; then
            return 0
        fi
        sleep "$interval_seconds"
    done
    return 1
}

uclaw_pick_gateway_port() {
    local port
    for port in $(seq "$GATEWAY_PORT_START" "$GATEWAY_PORT_END"); do
        if ! ss -tln 2>/dev/null | grep -q ":${port} "; then
            printf '%s\n' "$port"
            return 0
        fi
    done
    return 1
}

uclaw_start_config_server() {
    local node_bin="$1"
    local log_dir="$DATA_DIR/logs"
    mkdir -p "$log_dir"
    nohup "$node_bin" "$UCLAW_DIR/config-server/server.js" >"$log_dir/config-server.log" 2>&1 &
    printf '%s\n' "$!"
}

uclaw_start_hermes_server_bg() {
    local model_path="$1"
    local log_dir="$DATA_DIR/logs"
    mkdir -p "$log_dir"
    nohup "$LLAMA_SERVER" -m "$model_path" --host 127.0.0.1 --port "$MODEL_PORT" --alias hermes-local -c 4096 -ngl 0 >"$log_dir/hermes-local.log" 2>&1 &
    printf '%s\n' "$!"
}

uclaw_open_browser_if_available() {
    local url="$1"
    if [[ -n "${UCLAW_NO_BROWSER:-}" ]]; then
        return 0
    fi
    if [[ -n "${DISPLAY:-}" || -n "${WAYLAND_DISPLAY:-}" ]] && command -v xdg-open >/dev/null 2>&1; then
        (sleep 3 && xdg-open "$url" >/dev/null 2>&1 || true) &
    fi
}

uclaw_status_report() {
    local node_bin="$NODE_BIN"
    local llama_server="$LLAMA_SERVER"
    local model_path=""

    printf 'U-Claw Linux support\n'
    printf '  root: %s\n' "$UCLAW_DIR"
    printf '  cache: %s\n' "$(uclaw_linux_cache_root)"
    printf '  openclaw-state: %s\n' "$(uclaw_openclaw_state_dir)"
    printf '  openclaw-core-stage: %s\n' "$(uclaw_openclaw_core_stage_root)"
    printf '  node: %s\n' "$node_bin"
    printf '  llama-server: %s\n' "$llama_server"
    printf '  config: %s\n' "$OPENCLAW_CONFIG_PATH"

    if [[ -x "$node_bin" ]]; then
        printf '  node-version: %s\n' "$("$node_bin" --version 2>/dev/null || true)"
        if command -v file >/dev/null 2>&1; then
            printf '  node-file: %s\n' "$(file "$node_bin")"
        fi
    else
        printf '  node-version: missing\n'
    fi

    if [[ -x "$llama_server" ]]; then
        if command -v file >/dev/null 2>&1; then
            printf '  llama-file: %s\n' "$(file "$llama_server")"
        fi
    else
        printf '  llama-file: missing\n'
    fi

    if model_path="$(uclaw_find_model 2>/dev/null)"; then
        printf '  model: %s\n' "$model_path"
        if command -v file >/dev/null 2>&1; then
            printf '  model-file: %s\n' "$(file "$model_path")"
        fi
    else
        printf '  model: missing\n'
    fi
}

if [[ "${BASH_SOURCE[0]}" == "$0" ]]; then
    case "${1:-status}" in
        prepare)
            uclaw_prepare_linux_runtime
            ;;
        stage-openclaw|stage)
            uclaw_prepare_openclaw_deps
            uclaw_prepare_openclaw_core_stage
            ;;
        status|check)
            uclaw_status_report
            ;;
        *)
            printf 'Usage: %s [prepare|stage-openclaw|status|check]\n' "$0" >&2
            exit 2
            ;;
    esac
fi
