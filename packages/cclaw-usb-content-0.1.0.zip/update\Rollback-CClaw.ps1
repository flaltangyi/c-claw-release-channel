param(
    [Parameter(Mandatory = $true)]
    [string]$UsbRoot,

    [string]$BackupName = "",

    [switch]$Yes
)

$ErrorActionPreference = "Stop"

function Get-PreUpdateBackups {
    param([Parameter(Mandatory = $true)][string]$BackupRoot)

    if (-not (Test-Path -LiteralPath $BackupRoot)) {
        return @()
    }

    return @(
        Get-ChildItem -LiteralPath $BackupRoot -Directory -Filter "pre-update-*" -ErrorAction SilentlyContinue |
            Sort-Object @{ Expression = "LastWriteTime"; Descending = $true }, @{ Expression = "Name"; Descending = $true }
    )
}

function Select-Backup {
    param(
        [Parameter(Mandatory = $true)]
        [object[]]$Backups,

        [string]$RequestedName = ""
    )

    if (-not [string]::IsNullOrWhiteSpace($RequestedName)) {
        $match = $Backups | Where-Object {
            $_.Name -eq $RequestedName -or $_.FullName -eq $RequestedName
        } | Select-Object -First 1

        if (-not $match) {
            throw "Backup not found: $RequestedName"
        }

        return $match
    }

    if ($Backups.Count -eq 1) {
        return $Backups[0]
    }

    Write-Host ""
    Write-Host "  Choose a rollback backup. Press Enter to use the latest one:"
    for ($i = 0; $i -lt $Backups.Count; $i++) {
        $marker = if ($i -eq 0) { " [latest]" } else { "" }
        Write-Host ("  [{0}] {1}{2}" -f ($i + 1), $Backups[$i].Name, $marker)
    }

    $choice = Read-Host "  Backup number"
    if ([string]::IsNullOrWhiteSpace($choice)) {
        return $Backups[0]
    }

    if ($choice -match '^\d+$') {
        $index = [int]$choice
        if ($index -ge 1 -and $index -le $Backups.Count) {
            return $Backups[$index - 1]
        }
    }

    Write-Host "  Invalid choice. Using the latest backup."
    return $Backups[0]
}

function Copy-BackupFiles {
    param(
        [Parameter(Mandatory = $true)]
        [string]$BackupPath,

        [Parameter(Mandatory = $true)]
        [string]$TargetRoot
    )

    $backupRoot = (Resolve-Path -LiteralPath $BackupPath).Path.TrimEnd([IO.Path]::DirectorySeparatorChar, [IO.Path]::AltDirectorySeparatorChar)
    $backupPrefix = $backupRoot + [IO.Path]::DirectorySeparatorChar
    $files = Get-ChildItem -LiteralPath $BackupPath -Recurse -File -Force

    if (-not $files -or $files.Count -eq 0) {
        throw "Backup has no files to restore: $BackupPath"
    }

    $restored = New-Object System.Collections.Generic.List[string]
    foreach ($file in $files) {
        $relative = $file.FullName.Substring($backupPrefix.Length)
        $destination = Join-Path $TargetRoot $relative
        $destinationDir = Split-Path -Parent $destination

        if (-not [string]::IsNullOrWhiteSpace($destinationDir)) {
            New-Item -ItemType Directory -Force -Path $destinationDir | Out-Null
        }

        Copy-Item -LiteralPath $file.FullName -Destination $destination -Force
        [void]$restored.Add($relative)
    }

    return $restored
}

$UsbRoot = (Resolve-Path -LiteralPath $UsbRoot).Path
$BackupRoot = Join-Path $UsbRoot "data\backups"
$Backups = Get-PreUpdateBackups -BackupRoot $BackupRoot

if ($Backups.Count -eq 0) {
    Write-Host "[INFO] No pre-update-* rollback backup was found."
    Write-Host "       Run an update first to create a rollback point."
    exit 0
}

Write-Host ""
Write-Host "  Available rollback backups:"
for ($i = 0; $i -lt $Backups.Count; $i++) {
    $backup = $Backups[$i]
    $count = @(Get-ChildItem -LiteralPath $backup.FullName -Recurse -File -Force).Count
    $tag = if ($i -eq 0) { " [latest]" } else { "" }
    Write-Host ("  [{0}] {1}{2} ({3} files)" -f ($i + 1), $backup.Name, $tag, $count)
}

$SelectedBackup = Select-Backup -Backups $Backups -RequestedName $BackupName

Write-Host ""
Write-Host "  Rollback target:"
Write-Host "    $($SelectedBackup.FullName)"
Write-Host "  Only files present in the backup will be restored."
Write-Host "  This action does not delete data, models, or local-model."
Write-Host ""
if (-not $Yes) {
    $confirm = Read-Host "  Type ROLLBACK to confirm"
    if ($confirm -ne "ROLLBACK") {
        Write-Host "  [INFO] Cancelled."
        exit 0
    }
} else {
    Write-Host "  [INFO] -Yes was supplied. Skipping interactive confirmation."
}

Write-Host ""
Write-Host "  Restoring backup files..."
$restored = Copy-BackupFiles -BackupPath $SelectedBackup.FullName -TargetRoot $UsbRoot

Write-Host ""
Write-Host "  [OK] Rollback complete."
Write-Host "  Restored files:"
foreach ($item in $restored) {
    Write-Host "    + $item"
}
Write-Host ""
Write-Host "  Restart C-CLAW or reopen the menu to use the restored version."
