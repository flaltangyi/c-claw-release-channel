function Get-CClawLicenseDefaultPath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$UsbRoot
    )

    return (Join-Path $UsbRoot "data\license\cclaw-license.json")
}

function Get-CClawLicensePublicKeyDefaultPath {
    return (Join-Path $PSScriptRoot "cclaw-license-rsa-v1.xml")
}

function New-CClawLicensePayloadObject {
    param(
        [Parameter(Mandatory = $true)]
        [object]$License
    )

    $features = @()
    if ($License.PSObject.Properties.Name -contains "features" -and $null -ne $License.features) {
        $features = @($License.features | ForEach-Object { [string]$_ })
    }

    return [ordered]@{
        schemaVersion = [int]$License.schemaVersion
        product       = [string]$License.product
        licenseId     = [string]$License.licenseId
        edition       = [string]$License.edition
        channel       = [string]$License.channel
        issuedAt      = [string]$License.issuedAt
        supportUntil  = [string]$License.supportUntil
        updatesUntil  = [string]$License.updatesUntil
        features      = $features
        orderId       = [string]$License.orderId
        customerRef   = [string]$License.customerRef
        notes         = [string]$License.notes
    }
}

function ConvertTo-CClawLicensePayloadJson {
    param(
        [Parameter(Mandatory = $true)]
        [object]$License
    )

    $payload = New-CClawLicensePayloadObject -License $License
    return ($payload | ConvertTo-Json -Depth 20 -Compress)
}

function Get-CClawTextSha256Digest {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Text
    )

    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Text)
    $sha256 = [System.Security.Cryptography.SHA256]::Create()
    try {
        $hashBytes = $sha256.ComputeHash($bytes)
    } finally {
        $sha256.Dispose()
    }

    return [pscustomobject]@{
        Bytes = $hashBytes
        Hex   = (($hashBytes | ForEach-Object { $_.ToString("X2") }) -join "")
    }
}

function Test-CClawDateActive {
    param(
        [string]$DateText
    )

    if ([string]::IsNullOrWhiteSpace($DateText)) {
        return $true
    }

    try {
        $date = [datetimeoffset]::Parse($DateText, [System.Globalization.CultureInfo]::InvariantCulture)
        return ([datetimeoffset]::Now.Date -le $date.Date)
    } catch {
        return $false
    }
}

function New-CClawLicenseResult {
    param(
        [bool]$IsValid,
        [string]$Status,
        [string]$Message,
        [string]$LicensePath = "",
        [object]$License = $null
    )

    $supportActive = $false
    $updatesActive = $false
    $features = @()
    if ($null -ne $License) {
        $supportActive = Test-CClawDateActive -DateText ([string]$License.supportUntil)
        $updatesActive = Test-CClawDateActive -DateText ([string]$License.updatesUntil)
        if ($License.PSObject.Properties.Name -contains "features" -and $null -ne $License.features) {
            $features = @($License.features | ForEach-Object { [string]$_ })
        }
    }

    return [pscustomobject]@{
        IsValid       = $IsValid
        Status        = $Status
        Message       = $Message
        LicensePath   = $LicensePath
        LicenseId     = if ($null -ne $License) { [string]$License.licenseId } else { "" }
        Edition       = if ($null -ne $License) { [string]$License.edition } else { "" }
        Channel       = if ($null -ne $License) { [string]$License.channel } else { "" }
        IssuedAt      = if ($null -ne $License) { [string]$License.issuedAt } else { "" }
        SupportUntil  = if ($null -ne $License) { [string]$License.supportUntil } else { "" }
        SupportActive = $supportActive
        UpdatesUntil  = if ($null -ne $License) { [string]$License.updatesUntil } else { "" }
        UpdatesActive = $updatesActive
        Features      = $features
    }
}

function Test-CClawLicense {
    param(
        [Parameter(Mandatory = $true)]
        [string]$UsbRoot,

        [string]$LicensePath = "",

        [string]$PublicKeyPath = ""
    )

    if ([string]::IsNullOrWhiteSpace($LicensePath)) {
        $LicensePath = Get-CClawLicenseDefaultPath -UsbRoot $UsbRoot
    }
    if ([string]::IsNullOrWhiteSpace($PublicKeyPath)) {
        $PublicKeyPath = Get-CClawLicensePublicKeyDefaultPath
    }

    if (-not (Test-Path -LiteralPath $LicensePath)) {
        return New-CClawLicenseResult -IsValid $false -Status "Missing" -Message "License file is missing." -LicensePath $LicensePath
    }
    if (-not (Test-Path -LiteralPath $PublicKeyPath)) {
        return New-CClawLicenseResult -IsValid $false -Status "Invalid" -Message "License public key is missing." -LicensePath $LicensePath
    }

    try {
        $license = Get-Content -LiteralPath $LicensePath -Raw -Encoding UTF8 | ConvertFrom-Json
    } catch {
        return New-CClawLicenseResult -IsValid $false -Status "Invalid" -Message "License JSON is invalid: $($_.Exception.Message)" -LicensePath $LicensePath
    }

    if ($null -eq $license.signature) {
        return New-CClawLicenseResult -IsValid $false -Status "Invalid" -Message "License signature is missing." -LicensePath $LicensePath -License $license
    }

    $algorithm = [string]$license.signature.algorithm
    $publicKeyId = [string]$license.signature.publicKeyId
    $payloadSha256 = [string]$license.signature.payloadSha256
    $signatureBase64 = [string]$license.signature.valueBase64

    if ($algorithm -ne "RSA-SHA256") {
        return New-CClawLicenseResult -IsValid $false -Status "Invalid" -Message "Unsupported license signature algorithm '$algorithm'." -LicensePath $LicensePath -License $license
    }
    if ([string]::IsNullOrWhiteSpace($publicKeyId)) {
        return New-CClawLicenseResult -IsValid $false -Status "Invalid" -Message "License publicKeyId is empty." -LicensePath $LicensePath -License $license
    }
    if ([string]::IsNullOrWhiteSpace($signatureBase64)) {
        return New-CClawLicenseResult -IsValid $false -Status "Invalid" -Message "License signature value is empty." -LicensePath $LicensePath -License $license
    }

    $expectedPublicKeyId = [System.IO.Path]::GetFileNameWithoutExtension((Resolve-Path -LiteralPath $PublicKeyPath).Path)
    if ($publicKeyId -ne $expectedPublicKeyId) {
        return New-CClawLicenseResult -IsValid $false -Status "Invalid" -Message "License publicKeyId '$publicKeyId' does not match bundled key '$expectedPublicKeyId'." -LicensePath $LicensePath -License $license
    }

    try {
        $payloadJson = ConvertTo-CClawLicensePayloadJson -License $license
        $digest = Get-CClawTextSha256Digest -Text $payloadJson
    } catch {
        return New-CClawLicenseResult -IsValid $false -Status "Invalid" -Message "License payload cannot be canonicalized: $($_.Exception.Message)" -LicensePath $LicensePath -License $license
    }

    if ([string]::IsNullOrWhiteSpace($payloadSha256) -or $payloadSha256.ToUpperInvariant() -ne $digest.Hex) {
        return New-CClawLicenseResult -IsValid $false -Status "Invalid" -Message "License payload SHA256 mismatch." -LicensePath $LicensePath -License $license
    }

    $signatureHelperPath = Join-Path (Split-Path -Parent $PSScriptRoot) "update\CClaw-Signature.ps1"
    if (-not (Test-Path -LiteralPath $signatureHelperPath)) {
        return New-CClawLicenseResult -IsValid $false -Status "Invalid" -Message "Signature helper is missing." -LicensePath $LicensePath -License $license
    }
    . $signatureHelperPath

    try {
        $ok = Test-CClawRsaSignatureBase64 -PublicKeyPath $PublicKeyPath -HashBytes $digest.Bytes -SignatureBase64 $signatureBase64
    } catch {
        return New-CClawLicenseResult -IsValid $false -Status "Invalid" -Message "License signature verification failed: $($_.Exception.Message)" -LicensePath $LicensePath -License $license
    }

    if (-not $ok) {
        return New-CClawLicenseResult -IsValid $false -Status "Invalid" -Message "License RSA signature is invalid." -LicensePath $LicensePath -License $license
    }

    return New-CClawLicenseResult -IsValid $true -Status "Valid" -Message "License signature is valid." -LicensePath $LicensePath -License $license
}

function Assert-CClawLicense {
    param(
        [Parameter(Mandatory = $true)]
        [string]$UsbRoot,

        [ValidateSet("startup", "updates", "hermes-model", "support")]
        [string]$Purpose = "startup",

        [string]$LicensePath = "",

        [string]$PublicKeyPath = ""
    )

    $result = Test-CClawLicense -UsbRoot $UsbRoot -LicensePath $LicensePath -PublicKeyPath $PublicKeyPath
    if (-not $result.IsValid) {
        throw "C-CLAW license check failed: $($result.Status). $($result.Message)"
    }

    if (($Purpose -eq "updates" -or $Purpose -eq "hermes-model") -and -not $result.UpdatesActive) {
        throw "C-CLAW updates are not active for license '$($result.LicenseId)'. updatesUntil=$($result.UpdatesUntil)"
    }

    return $result
}
