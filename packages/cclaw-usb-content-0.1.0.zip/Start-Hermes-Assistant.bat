@echo off
set "C_CLAW_ASSISTANT_LAUNCH=1"
call "%~dp0Start-Hermes-Local.bat"
