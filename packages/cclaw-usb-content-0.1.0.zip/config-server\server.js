#!/usr/bin/env node
const http = require('http');
const fs = require('fs');
const path = require('path');
const { deflateSync } = require('zlib');
const crypto = require('crypto');
const semver = require(path.join(__dirname, '../app/core/node_modules/semver'));

const PORT_RANGE_START = 18788;
const PORT_RANGE_END = 18798;
const CONFIG_PATH = path.join(__dirname, '../data/.openclaw/openclaw.json');
const RUNTIME_PATH = path.join(__dirname, '../data/.openclaw/runtime.json');
const PUBLIC_ROOT = path.resolve(__dirname, 'public');
const CONFIG_SERVER_TOKEN_HEADER = 'x-config-token';
const CONFIG_BOOTSTRAP_PLACEHOLDER = '__CONFIG_SERVER_BOOTSTRAP__';
let currentConfigServerPort = PORT_RANGE_START;
let configServerToken = crypto.randomBytes(32).toString('base64url');

// 鈹€鈹€ WeChat Login State 鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€
const DEFAULT_WECHAT_BASE_URL = 'https://ilinkai.weixin.qq.com';
const DEFAULT_ILINK_BOT_TYPE = '3';
const ACTIVE_LOGIN_TTL_MS = 5 * 60000;
const QR_POLL_TIMEOUT_MS = 35000;
const MAX_QR_REFRESH_COUNT = 3;

// Resolve ~/.openclaw/ directory
const OPENCLAW_DIR = process.env.OPENCLAW_STATE_DIR ||
  path.join(process.env.USERPROFILE || process.env.HOME || require('os').homedir(), '.openclaw');
const WECHAT_STATE_DIR = path.join(OPENCLAW_DIR, 'openclaw-weixin');
const WECHAT_ACCOUNTS_DIR = path.join(WECHAT_STATE_DIR, 'accounts');
const WECHAT_ACCOUNT_INDEX_FILE = path.join(WECHAT_STATE_DIR, 'accounts.json');

// Plugin source on USB
const USB_PLUGIN_DIR = path.join(__dirname, '../app/extensions/openclaw-weixin');
const INSTALLED_PLUGIN_DIR = path.join(OPENCLAW_DIR, 'extensions', 'openclaw-weixin');
const OPENCLAW_CORE_PACKAGE_PATH = path.join(__dirname, '../app/core/node_modules/openclaw/package.json');
const WECHAT_PLUGIN_MISSING_MESSAGE = 'Personal WeChat plugin is not bundled in this USB release. Install @tencent-weixin/openclaw-weixin and restart Gateway.';

const activeLogins = new Map();

function readJsonFile(filePath) {
  if (!fs.existsSync(filePath)) {
    return { exists: false, value: null, error: '' };
  }
  try {
    return {
      exists: true,
      value: JSON.parse(fs.readFileSync(filePath, 'utf8').replace(/^\uFEFF/, '')),
      error: '',
    };
  } catch (error) {
    return { exists: true, value: null, error: error.message };
  }
}

function getOpenClawHostVersion() {
  const hostPackage = readJsonFile(OPENCLAW_CORE_PACKAGE_PATH);
  return hostPackage.value && typeof hostPackage.value.version === 'string'
    ? hostPackage.value.version
    : '';
}

function inspectWeChatPluginDir(pluginDir) {
  const exists = fs.existsSync(pluginDir);
  const manifestPath = path.join(pluginDir, 'openclaw.plugin.json');
  const packagePath = path.join(pluginDir, 'package.json');
  const runtimeEntryPath = path.join(pluginDir, 'dist', 'index.js');
  const manifestRead = readJsonFile(manifestPath);
  const packageRead = readJsonFile(packagePath);
  const manifest = manifestRead.value || {};
  const packageJson = packageRead.value || {};
  const missingFiles = [];

  if (!manifestRead.exists) missingFiles.push('openclaw.plugin.json');
  else if (manifestRead.error) missingFiles.push(`openclaw.plugin.json (${manifestRead.error})`);

  if (!packageRead.exists) missingFiles.push('package.json');
  else if (packageRead.error) missingFiles.push(`package.json (${packageRead.error})`);

  if (!fs.existsSync(runtimeEntryPath)) missingFiles.push('dist/index.js');

  const pluginVersion = typeof manifest.version === 'string'
    ? manifest.version
    : (typeof packageJson.version === 'string' ? packageJson.version : '');
  const minHostVersion = typeof manifest?.openclaw?.install?.minHostVersion === 'string'
    ? manifest.openclaw.install.minHostVersion
    : (typeof packageJson?.peerDependencies?.openclaw === 'string' ? packageJson.peerDependencies.openclaw : '');
  const hostVersion = getOpenClawHostVersion();

  let compatible = true;
  let compatibilityDetail = '';
  if (exists && !missingFiles.length && minHostVersion) {
    try {
      compatible = semver.satisfies(hostVersion, minHostVersion, { includePrerelease: true });
    } catch (error) {
      compatible = false;
      compatibilityDetail = error.message;
    }
  }

  let status = 'missing';
  let message = WECHAT_PLUGIN_MISSING_MESSAGE;
  if (exists) {
    if (missingFiles.length) {
      status = 'broken';
      message = `openclaw-weixin ���Ŀ¼��������ȱ�� ${missingFiles.join('��')}��`;
    } else if (!compatible) {
      status = 'version-mismatch';
      message = `openclaw-weixin ${pluginVersion || 'unknown'} ��Ҫ OpenClaw ${minHostVersion || 'unknown'}������ǰ�����汾�� ${hostVersion || 'unknown'}��`;
      if (compatibilityDetail) {
        message += ` ${compatibilityDetail}`;
      }
    } else {
      status = 'ready';
      message = '';
    }
  }

  return {
    exists,
    manifestExists: manifestRead.exists && !manifestRead.error,
    packageExists: packageRead.exists && !packageRead.error,
    runtimeExists: fs.existsSync(runtimeEntryPath),
    ready: status === 'ready',
    status,
    message,
    pluginVersion,
    hostVersion,
    minHostVersion,
    missingFiles,
    manifestPath,
    packagePath,
    runtimeEntryPath,
  };
}

function getWeChatPluginState() {
  const bundledState = inspectWeChatPluginDir(USB_PLUGIN_DIR);
  const installedState = inspectWeChatPluginDir(INSTALLED_PLUGIN_DIR);
  const sourceState = bundledState.ready
    ? { ...bundledState, source: 'bundled' }
    : installedState.ready
      ? { ...installedState, source: 'installed' }
      : bundledState.exists
        ? { ...bundledState, source: 'bundled' }
        : installedState.exists
          ? { ...installedState, source: 'installed' }
          : null;

  return {
    bundled: bundledState.exists,
    installed: installedState.exists,
    available: !!sourceState && sourceState.ready,
    ready: !!sourceState && sourceState.ready,
    status: sourceState ? sourceState.status : 'missing',
    source: sourceState ? sourceState.source : 'missing',
    message: sourceState ? sourceState.message : WECHAT_PLUGIN_MISSING_MESSAGE,
    pluginVersion: sourceState ? sourceState.pluginVersion : '',
    hostVersion: sourceState ? sourceState.hostVersion : getOpenClawHostVersion(),
    minHostVersion: sourceState ? sourceState.minHostVersion : '',
    bundledState,
    installedState,
  };
}

function isAllowedOrigin(originValue) {
  if (!originValue) return true;
  let parsed;
  try {
    parsed = new URL(originValue);
  } catch {
    return false;
  }
  if (parsed.protocol !== 'http:') return false;
  const port = parsed.port || (parsed.protocol === 'http:' ? '80' : '');
  const currentPort = String(currentConfigServerPort);
  if (port !== currentPort) return false;
  return parsed.hostname === '127.0.0.1'
    || parsed.hostname === 'localhost'
    || parsed.hostname === '::1'
    || parsed.hostname === '[::1]';
}

function getRequestOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return '';
  if (!isAllowedOrigin(origin)) return null;
  return origin;
}

function applySecurityHeaders(res, origin) {
  if (origin) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
}

function sendJson(res, statusCode, payload, origin) {
  applySecurityHeaders(res, origin);
  res.writeHead(statusCode, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify(payload));
}

function sendText(res, statusCode, text, contentType, origin) {
  applySecurityHeaders(res, origin);
  res.writeHead(statusCode, { 'Content-Type': contentType || 'text/plain; charset=utf-8' });
  res.end(text);
}

function withTimeout(ms) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), ms);
  return {
    signal: controller.signal,
    clear: () => clearTimeout(timer),
  };
}

async function fetchHermesModels() {
  const timeout = withTimeout(5000);
  try {
    const response = await fetch('http://127.0.0.1:11435/v1/models', {
      method: 'GET',
      signal: timeout.signal,
    });
    const bodyText = await response.text();
    return {
      ok: response.ok,
      status: response.status,
      body: bodyText ? JSON.parse(bodyText) : {},
    };
  } finally {
    timeout.clear();
  }
}

async function callHermesChat(payload) {
  const timeout = withTimeout(180000);
  try {
    const response = await fetch('http://127.0.0.1:11435/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
      signal: timeout.signal,
    });
    const bodyText = await response.text();
    const body = bodyText ? JSON.parse(bodyText) : {};
    if (!response.ok) {
      const detail = body && (body.error || body.message) ? (body.error || body.message) : bodyText;
      throw new Error(`Hermes request failed (${response.status}): ${detail || 'empty response'}`);
    }
    return body;
  } finally {
    timeout.clear();
  }
}

function normalizeHermesMessages(value, prompt) {
  if (Array.isArray(value) && value.length > 0) {
    return value
      .filter(item => item && typeof item === 'object' && typeof item.content === 'string')
      .map(item => ({
        role: ['system', 'assistant', 'user'].includes(item.role) ? item.role : 'user',
        content: item.content,
      }));
  }
  const textValue = typeof prompt === 'string' ? prompt.trim() : '';
  return textValue ? [{ role: 'user', content: textValue }] : [];
}

function readRequestBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 10 * 1024 * 1024) {
        reject(new Error('Request body too large'));
        req.destroy();
      }
    });
    req.on('end', () => resolve(body));
    req.on('error', reject);
  });
}

function isSensitiveKey(key) {
  return /(?:api[_-]?key|token|secret|password|clientsecret|appsecret|accesstoken|refreshtoken|authorization)/i.test(String(key || ''));
}

function maskApiKey(value) {
  const text = String(value || '');
  if (!text) return text;
  if (text.length <= 8) return '***REDACTED***';
  return `${text.slice(0, 8)}...${text.slice(-4)}`;
}

function isMaskedSecretValue(value) {
  return typeof value === 'string' && (value.includes('...') || value.includes('***REDACTED***'));
}

function sanitizeForClient(value, key) {
  if (Array.isArray(value)) {
    return value.map(item => sanitizeForClient(item));
  }
  if (value && typeof value === 'object') {
    const output = {};
    for (const [childKey, childValue] of Object.entries(value)) {
      output[childKey] = sanitizeForClient(childValue, childKey);
    }
    return output;
  }
  if (isSensitiveKey(key) && typeof value === 'string') {
    return String(key).toLowerCase() === 'apikey' ? maskApiKey(value) : '***REDACTED***';
  }
  return value;
}

function mergePreservingSecrets(existing, incoming, key) {
  if (incoming === undefined) return existing;
  if (Array.isArray(incoming)) {
    return incoming.map((item, index) => mergePreservingSecrets(Array.isArray(existing) ? existing[index] : undefined, item));
  }
  if (incoming && typeof incoming === 'object') {
    const merged = existing && typeof existing === 'object' && !Array.isArray(existing)
      ? { ...existing }
      : {};
    for (const [childKey, childValue] of Object.entries(incoming)) {
      merged[childKey] = mergePreservingSecrets(existing ? existing[childKey] : undefined, childValue, childKey);
    }
    return merged;
  }
  if (isSensitiveKey(key)) {
    if (incoming === '' || incoming == null || isMaskedSecretValue(incoming)) {
      return existing;
    }
  }
  return incoming;
}

function parseRequestPath(reqUrl) {
  const base = `http://127.0.0.1:${currentConfigServerPort}`;
  const url = new URL(reqUrl, base);
  const pathname = decodeURIComponent(url.pathname || '/');
  return pathname === '/' ? '/index.html' : pathname;
}

function resolvePublicFilePath(reqUrl) {
  let pathname;
  try {
    pathname = parseRequestPath(reqUrl);
  } catch {
    return { statusCode: 404 };
  }
  const relativePath = pathname.replace(/^\/+/, '');
  const filePath = path.resolve(PUBLIC_ROOT, relativePath);
  const rootWithSep = PUBLIC_ROOT.endsWith(path.sep) ? PUBLIC_ROOT : PUBLIC_ROOT + path.sep;
  if (filePath !== PUBLIC_ROOT && !filePath.startsWith(rootWithSep)) {
    return { statusCode: 403 };
  }
  return { filePath };
}

function servePublicFile(req, res) {
  const resolved = resolvePublicFilePath(req.url || '/');
  if (resolved.statusCode) {
    sendText(res, resolved.statusCode, resolved.statusCode === 403 ? 'Forbidden' : 'Not Found', 'text/plain; charset=utf-8');
    return;
  }
  if (!fs.existsSync(resolved.filePath) || !fs.statSync(resolved.filePath).isFile()) {
    sendText(res, 404, 'Not Found', 'text/plain; charset=utf-8');
    return;
  }
  const ext = path.extname(resolved.filePath).toLowerCase();
  let body = fs.readFileSync(resolved.filePath);
  const contentType = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
  }[ext] || 'text/plain; charset=utf-8';

  if (ext === '.html') {
    const bootstrap = JSON.stringify({
      port: currentConfigServerPort,
      token: configServerToken,
    });
    const html = body.toString('utf8').replace(CONFIG_BOOTSTRAP_PLACEHOLDER, bootstrap);
    body = Buffer.from(html, 'utf8');
  }

  applySecurityHeaders(res);
  res.writeHead(200, { 'Content-Type': contentType });
  res.end(body);
}

function requireConfigToken(req, res, origin) {
  const token = req.headers[CONFIG_SERVER_TOKEN_HEADER];
  if (!token) {
    sendJson(res, 401, { error: 'Missing config token' }, origin);
    return false;
  }
  if (token !== configServerToken) {
    sendJson(res, 403, { error: 'Invalid config token' }, origin);
    return false;
  }
  return true;
}

function writeRuntimeState(port) {
  try {
    fs.mkdirSync(path.dirname(RUNTIME_PATH), { recursive: true });
    const existing = fs.existsSync(RUNTIME_PATH) ? JSON.parse(fs.readFileSync(RUNTIME_PATH, 'utf8')) : {};
    existing.configServerPort = port;
    delete existing.configServerToken;
    existing.configServerUpdatedAt = new Date().toISOString();
    fs.writeFileSync(RUNTIME_PATH, JSON.stringify(existing, null, 2));
  } catch (err) {
    console.warn(`   Warning: could not write ${RUNTIME_PATH}: ${err.message}`);
  }
}

// 鈹€鈹€ QR Code PNG Renderer (pure Node.js, no external deps) 鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€

function getQrRenderDeps() {
  // Try to load QR lib from openclaw's bundled qrcode-terminal
  const corePath = path.join(__dirname, '../app/core/node_modules');
  const candidates = [
    path.join(corePath, 'qrcode-terminal/vendor/QRCode/index.js'),
    path.join(corePath, 'openclaw/node_modules/qrcode-terminal/vendor/QRCode/index.js'),
  ];
  const errCandidates = [
    path.join(corePath, 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js'),
    path.join(corePath, 'openclaw/node_modules/qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js'),
  ];
  for (let i = 0; i < candidates.length; i++) {
    if (fs.existsSync(candidates[i])) {
      return { QRCode: require(candidates[i]), QRErrorCorrectLevel: require(errCandidates[i]) };
    }
  }
  // Fallback: try WeChat plugin's own node_modules
  const pluginQr = path.join(USB_PLUGIN_DIR, 'node_modules/qrcode-terminal/vendor/QRCode/index.js');
  const pluginQrErr = path.join(USB_PLUGIN_DIR, 'node_modules/qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js');
  if (fs.existsSync(pluginQr)) {
    return { QRCode: require(pluginQr), QRErrorCorrectLevel: require(pluginQrErr) };
  }
  throw new Error('QR code library not found');
}

function createQrMatrix(input) {
  const { QRCode, QRErrorCorrectLevel } = getQrRenderDeps();
  const qr = new QRCode(-1, QRErrorCorrectLevel.L);
  qr.addData(input);
  qr.make();
  return qr;
}

function fillPixel(buf, x, y, width, r, g, b, a) {
  const idx = (y * width + x) * 4;
  buf[idx] = r; buf[idx + 1] = g; buf[idx + 2] = b; buf[idx + 3] = (a === undefined ? 255 : a);
}

const CRC_TABLE = (function() {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(buf) {
  let crc = 0xffffffff;
  for (let i = 0; i < buf.length; i++) crc = CRC_TABLE[(crc ^ buf[i]) & 0xff] ^ (crc >>> 8);
  return (crc ^ 0xffffffff) >>> 0;
}

function pngChunk(type, data) {
  const typeBuf = Buffer.from(type, 'ascii');
  const len = Buffer.alloc(4); len.writeUInt32BE(data.length, 0);
  const crc = crc32(Buffer.concat([typeBuf, data]));
  const crcBuf = Buffer.alloc(4); crcBuf.writeUInt32BE(crc, 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

function encodePngRgba(buffer, width, height) {
  const stride = width * 4;
  const raw = Buffer.alloc((stride + 1) * height);
  for (let row = 0; row < height; row++) {
    const offset = row * (stride + 1);
    raw[offset] = 0;
    buffer.copy(raw, offset + 1, row * stride, row * stride + stride);
  }
  const compressed = deflateSync(raw);
  const signature = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0); ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; ihdr[9] = 6;
  return Buffer.concat([signature, pngChunk('IHDR', ihdr), pngChunk('IDAT', compressed), pngChunk('IEND', Buffer.alloc(0))]);
}

function renderQrPngDataUrl(input) {
  const scale = 6, margin = 4;
  const qr = createQrMatrix(input);
  const modules = qr.getModuleCount();
  const size = (modules + margin * 2) * scale;
  const buf = Buffer.alloc(size * size * 4, 255);
  for (let row = 0; row < modules; row++) {
    for (let col = 0; col < modules; col++) {
      if (!qr.isDark(row, col)) continue;
      const sx = (col + margin) * scale, sy = (row + margin) * scale;
      for (let y = 0; y < scale; y++) for (let x = 0; x < scale; x++)
        fillPixel(buf, sx + x, sy + y, size, 0, 0, 0, 255);
    }
  }
  return 'data:image/png;base64,' + encodePngRgba(buf, size, size).toString('base64');
}

// 鈹€鈹€ WeChat API helpers 鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€

async function fetchWeChatQrCode(apiBaseUrl) {
  const base = apiBaseUrl.endsWith('/') ? apiBaseUrl : apiBaseUrl + '/';
  const url = base + 'ilink/bot/get_bot_qrcode?bot_type=' + encodeURIComponent(DEFAULT_ILINK_BOT_TYPE);
  const response = await fetch(url);
  if (!response.ok) {
    const body = await response.text().catch(() => '');
    throw new Error('Failed to fetch QR: ' + response.status + ' ' + body);
  }
  return await response.json();
}

async function pollWeChatQrStatus(apiBaseUrl, qrcode) {
  const base = apiBaseUrl.endsWith('/') ? apiBaseUrl : apiBaseUrl + '/';
  const url = base + 'ilink/bot/get_qrcode_status?qrcode=' + encodeURIComponent(qrcode);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), QR_POLL_TIMEOUT_MS);
  try {
    const response = await fetch(url, {
      headers: { 'iLink-App-ClientVersion': '1' },
      signal: controller.signal
    });
    clearTimeout(timer);
    const text = await response.text();
    if (!response.ok) throw new Error('Poll failed: ' + response.status + ' ' + text);
    return JSON.parse(text);
  } catch (err) {
    clearTimeout(timer);
    if (err.name === 'AbortError') return { status: 'wait' };
    throw err;
  }
}

function normalizeAccountId(raw) {
  return String(raw).toLowerCase().replace(/[^a-z0-9._-]/g, '-');
}

async function saveWeChatAccount(rawAccountId, payload) {
  const accountId = normalizeAccountId(rawAccountId);
  fs.mkdirSync(WECHAT_ACCOUNTS_DIR, { recursive: true });
  const filePath = path.join(WECHAT_ACCOUNTS_DIR, accountId + '.json');
  const data = {
    token: payload.token.trim(),
    savedAt: new Date().toISOString(),
  };
  if (payload.baseUrl) data.baseUrl = payload.baseUrl.trim();
  if (payload.userId) data.userId = payload.userId.trim();
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

  // Update account index
  let accounts = [];
  try { accounts = JSON.parse(fs.readFileSync(WECHAT_ACCOUNT_INDEX_FILE, 'utf-8')); } catch {}
  if (!Array.isArray(accounts)) accounts = [];
  if (!accounts.includes(accountId)) {
    accounts.push(accountId);
    fs.mkdirSync(WECHAT_STATE_DIR, { recursive: true });
    fs.writeFileSync(WECHAT_ACCOUNT_INDEX_FILE, JSON.stringify(accounts, null, 2));
  }
  return accountId;
}

function ensureWeChatPluginInstalled() {
  const pluginState = getWeChatPluginState();
  if (pluginState.installedState && pluginState.installedState.ready) {
    return pluginState;
  }
  if (!pluginState.bundledState || !pluginState.bundledState.ready) {
    return pluginState;
  }
  // Copy from USB to ~/.openclaw/extensions/ and clear stale files first.
  const extDir = path.join(OPENCLAW_DIR, 'extensions');
  fs.mkdirSync(extDir, { recursive: true });
  if (fs.existsSync(INSTALLED_PLUGIN_DIR)) {
    fs.rmSync(INSTALLED_PLUGIN_DIR, { recursive: true, force: true });
  }
  copyDirSync(USB_PLUGIN_DIR, INSTALLED_PLUGIN_DIR);
  const refreshedState = getWeChatPluginState();
  return {
    ...refreshedState,
    installed: refreshedState.installed,
  };
}
function copyDirSync(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, entry.name);
    const d = path.join(dest, entry.name);
    if (entry.isDirectory()) copyDirSync(s, d);
    else fs.copyFileSync(s, d);
  }
}

// 鈹€鈹€ WeChat login session management 鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€鈹€

async function handleWeChatStart() {
  const pluginState = getWeChatPluginState();
  if (!pluginState.available) {
    throw new Error(pluginState.message);
  }

  const sessionKey = crypto.randomUUID();
  const apiBaseUrl = DEFAULT_WECHAT_BASE_URL;
  const qrResponse = await fetchWeChatQrCode(apiBaseUrl);
  const qrDataUrl = renderQrPngDataUrl(qrResponse.qrcode_img_content);

  activeLogins.set(sessionKey, {
    sessionKey,
    qrcode: qrResponse.qrcode,
    qrcodeUrl: qrDataUrl,
    startedAt: Date.now(),
    apiBaseUrl,
  });

  return { sessionKey, qrcodeUrl: qrDataUrl };
}

async function handleWeChatStatus(sessionKey) {
  const login = activeLogins.get(sessionKey);
  if (!login) return { status: 'expired', message: 'No active session' };
  if (Date.now() - login.startedAt > ACTIVE_LOGIN_TTL_MS) {
    activeLogins.delete(sessionKey);
    return { status: 'expired', message: 'Session expired' };
  }

  const result = await pollWeChatQrStatus(login.apiBaseUrl, login.qrcode);

  if (result.status === 'expired') {
    // Try to refresh QR code
    if (!login.refreshCount) login.refreshCount = 1;
    login.refreshCount++;
    if (login.refreshCount > MAX_QR_REFRESH_COUNT) {
      activeLogins.delete(sessionKey);
      return { status: 'expired', message: 'QR expired too many times' };
    }
    const refreshed = await fetchWeChatQrCode(login.apiBaseUrl);
    const newQr = renderQrPngDataUrl(refreshed.qrcode_img_content);
    login.qrcode = refreshed.qrcode;
    login.qrcodeUrl = newQr;
    login.startedAt = Date.now();
    return { status: 'refreshed', qrcodeUrl: newQr };
  }

  if (result.status === 'confirmed') {
    activeLogins.delete(sessionKey);
    if (!result.ilink_bot_id || !result.bot_token) {
      return { status: 'error', message: 'Server did not return credentials' };
    }

    // 1. Install plugin
    const pluginResult = ensureWeChatPluginInstalled();
    if (!pluginResult.available) {
      return { status: 'error', message: pluginResult.message };
    }

    // 2. Save account
    const accountId = await saveWeChatAccount(result.ilink_bot_id, {
      token: result.bot_token,
      baseUrl: result.baseurl,
      userId: result.ilink_user_id,
    });

    // 3. Update openclaw.json to enable the plugin
    try {
      const configRaw = fs.existsSync(CONFIG_PATH) ? fs.readFileSync(CONFIG_PATH, 'utf-8') : '{}';
      const config = JSON.parse(configRaw);
      if (!config.plugins) config.plugins = {};
      config.plugins.enabled = true;
      if (!config.plugins.entries) config.plugins.entries = {};
      config.plugins.entries['openclaw-weixin'] = { enabled: true };
      const dir = path.dirname(CONFIG_PATH);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
    } catch (e) {
      console.error('Failed to update config:', e.message);
    }

    return {
      status: 'confirmed',
      accountId,
      pluginInstalled: pluginResult.installed,
      message: 'WeChat connected! Restart Gateway to activate.',
    };
  }

  return { status: result.status };
}

function handleWeChatCancel(sessionKey) {
  if (sessionKey) activeLogins.delete(sessionKey);
  else activeLogins.clear();
}

const server = http.createServer((req, res) => {
  const origin = getRequestOrigin(req);
  if (origin === null) {
    sendJson(res, 403, { error: 'Origin not allowed' });
    return;
  }

  if (req.method === 'OPTIONS') {
    if (req.headers.origin && !isAllowedOrigin(req.headers.origin)) {
      sendJson(res, 403, { error: 'Origin not allowed' });
      return;
    }
    if (origin) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Vary', 'Origin');
    }
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Config-Token');
    res.setHeader('Access-Control-Max-Age', '600');
    res.writeHead(204);
    res.end();
    return;
  }

  // API: Hermes local model health
  if (req.url === '/api/hermes/status' && req.method === 'GET') {
    if (!requireConfigToken(req, res, origin)) return;
    fetchHermesModels()
      .then(result => sendJson(res, 200, { ok: result.ok, status: result.status, models: result.body }, origin))
      .catch(err => sendJson(res, 503, { ok: false, error: err.name === 'AbortError' ? 'Hermes local model did not respond in time.' : err.message }, origin));
    return;
  }

  // API: Hermes local chat proxy
  if (req.url === '/api/hermes/chat' && req.method === 'POST') {
    if (!requireConfigToken(req, res, origin)) return;
    readRequestBody(req)
      .then(body => {
        const data = body ? JSON.parse(body) : {};
        const messages = normalizeHermesMessages(data.messages, data.prompt);
        if (!messages.length) throw new Error('Message is empty.');
        const maxTokens = Number.isFinite(Number(data.maxTokens))
          ? Math.max(16, Math.min(512, Number(data.maxTokens)))
          : 48;
        const temperature = Number.isFinite(Number(data.temperature))
          ? Math.max(0, Math.min(1.5, Number(data.temperature)))
          : 0.7;
        return callHermesChat({
          model: 'hermes-local',
          messages,
          max_tokens: maxTokens,
          temperature,
          stream: false,
        });
      })
      .then(result => {
        const content = result?.choices?.[0]?.message?.content || result?.choices?.[0]?.text || '';
        sendJson(res, 200, { ok: true, content, raw: result }, origin);
      })
      .catch(err => sendJson(res, err.name === 'AbortError' ? 504 : 500, { ok: false, error: err.name === 'AbortError' ? 'Hermes local model did not respond in time.' : err.message }, origin));
    return;
  }

  // API: WeChat start login
  if (req.url === '/api/wechat/start' && req.method === 'POST') {
    if (!requireConfigToken(req, res, origin)) return;
    handleWeChatStart()
      .then(result => sendJson(res, 200, result, origin))
      .catch(err => sendJson(res, 500, { error: err.message }, origin));
    return;
  }

  // API: WeChat poll status
  if (req.url && req.url.startsWith('/api/wechat/status') && req.method === 'GET') {
    if (!requireConfigToken(req, res, origin)) return;
    const urlObj = new URL(req.url, 'http://localhost');
    const session = urlObj.searchParams.get('session');
    if (!session) {
      sendJson(res, 400, { error: 'Missing session parameter' }, origin);
      return;
    }
    handleWeChatStatus(session)
      .then(result => sendJson(res, 200, result, origin))
      .catch(err => sendJson(res, 500, { error: err.message }, origin));
    return;
  }

  // API: WeChat cancel
  if (req.url === '/api/wechat/cancel' && req.method === 'POST') {
    if (!requireConfigToken(req, res, origin)) return;
    readRequestBody(req)
      .then(body => {
        const data = body ? JSON.parse(body) : {};
        handleWeChatCancel(data.session);
        sendJson(res, 200, { ok: true }, origin);
      })
      .catch(err => sendJson(res, 500, { error: err.message }, origin));
    return;
  }

  // API: WeChat plugin status
  if (req.url === '/api/wechat/plugin-status' && req.method === 'GET') {
    if (!requireConfigToken(req, res, origin)) return;
    sendJson(res, 200, getWeChatPluginState(), origin);
    return;
  }

  // API: Get config
  if (req.url === '/api/config' && req.method === 'GET') {
    try {
      if (!requireConfigToken(req, res, origin)) return;
      const config = fs.existsSync(CONFIG_PATH)
        ? JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'))
        : {};
      sendJson(res, 200, sanitizeForClient(config), origin);
    } catch (err) {
      sendJson(res, 500, { error: err.message }, origin);
    }
    return;
  }

  // API: Xiapan Cloud status (fingerprint + apiKey + balance)
  if (req.url === '/api/xiapan/status' && req.method === 'GET') {
    if (!requireConfigToken(req, res, origin)) return;
    (async () => {
      try {
        const fpMod = await import('../lib/fingerprint.mjs');
        const xpMod = await import('../lib/xiapan-client.mjs');
        const portableRoot = path.join(__dirname, '..');
        const fp = await fpMod.getFingerprint(portableRoot);
        const apiKey = xpMod.buildApiKey(fp.fingerprint);
        const balance = await xpMod.getBalance(apiKey);
        const rechargeUrl = xpMod.getRechargeUrl(apiKey);
        sendJson(res, 200, {
          source: fp.source,
          apiKey: maskApiKey(apiKey),
          rechargeUrl,
          balance,
        }, origin);
      } catch (err) {
        sendJson(res, 500, { error: err.message }, origin);
      }
    })();
    return;
  }

  // API: Re-run bootstrap to inject the uclaw-cloud provider
  if (req.url === '/api/xiapan/bind' && req.method === 'POST') {
    if (!requireConfigToken(req, res, origin)) return;
    (async () => {
      try {
        const mod = await import('../lib/bootstrap-xiapan.mjs');
        const portableRoot = path.join(__dirname, '..');
        const result = await mod.bootstrapXiapan({
          configPath: CONFIG_PATH,
          appRoot: portableRoot,
        });
        if (result && typeof result === 'object' && result.apiKey) {
          result.apiKey = maskApiKey(result.apiKey);
        }
        sendJson(res, 200, result, origin);
      } catch (err) {
        sendJson(res, 500, { error: err.message }, origin);
      }
    })();
    return;
  }

  // API: Remove uclaw-cloud provider so the next bind regenerates it
  if (req.url === '/api/xiapan/unbind' && req.method === 'POST') {
    if (!requireConfigToken(req, res, origin)) return;
    try {
      if (fs.existsSync(CONFIG_PATH)) {
        const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
        if (config.models && config.models.providers && config.models.providers['uclaw-cloud']) {
          delete config.models.providers['uclaw-cloud'];
          fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
        }
      }
      sendJson(res, 200, { ok: true }, origin);
    } catch (err) {
      sendJson(res, 500, { error: err.message }, origin);
    }
    return;
  }

  // API: Save config
  if (req.url === '/api/config' && req.method === 'POST') {
    if (!requireConfigToken(req, res, origin)) return;
    readRequestBody(req)
      .then(body => {
        const config = JSON.parse(body);
        const existingConfig = fs.existsSync(CONFIG_PATH)
          ? JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'))
          : {};
        const mergedConfig = mergePreservingSecrets(existingConfig, config);
        // 娓呴櫎鏃х増搴熷純閿紝闃叉 OpenClaw �?"agent.* was moved" 閿欒�?
        delete mergedConfig.agent;
        const dir = path.dirname(CONFIG_PATH);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(CONFIG_PATH, JSON.stringify(mergedConfig, null, 2));
        sendJson(res, 200, { ok: true }, origin);
      })
      .catch(err => sendJson(res, 500, { error: err.message }, origin));
    return;
  }

  // Serve static files
  servePublicFile(req, res);
});

function listenWithFallback(port) {
  server.once('error', (err) => {
    if (err && err.code === 'EADDRINUSE' && port < PORT_RANGE_END) {
      console.log(`   Port ${port} busy, trying ${port + 1}...`);
      setImmediate(() => listenWithFallback(port + 1));
      return;
    }
    console.error(`Config server failed to bind: ${err && err.message ? err.message : err}`);
    process.exit(1);
  });
  server.listen(port, '127.0.0.1', () => {
    currentConfigServerPort = port;
    console.log(`\n馃 C-CLAW Config Center`);
    console.log(`   http://127.0.0.1:${port}`);
    console.log(`\n   Config file: ${CONFIG_PATH}\n`);
    writeRuntimeState(port);
  });
}

listenWithFallback(PORT_RANGE_START);
