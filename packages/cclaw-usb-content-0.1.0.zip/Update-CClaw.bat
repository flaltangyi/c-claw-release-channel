@echo off
title C-CLAW - Update

set "UCLAW_DIR=%~dp0"
for %%I in ("%~dp0.") do set "USB_ROOT=%%~fI"
set "SCRIPT=%~dp0update\Update-CClaw.ps1"

echo.
echo   ========================================
echo     C-CLAW Update
echo   ========================================
echo.

if not exist "%SCRIPT%" (
    echo   [ERROR] Missing update script:
    echo   %SCRIPT%
    echo.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -UsbRoot "%USB_ROOT%"
if errorlevel 1 (
    echo.
    echo   [FAILED] Update did not complete. Contact support and provide the support package.
)

echo.
pause
