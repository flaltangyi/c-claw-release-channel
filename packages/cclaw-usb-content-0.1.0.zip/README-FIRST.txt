第一版先记住这 5 件事：

1. Windows 本地模型版：打开 U 盘，先双击 `01-双击这里开始.html`，再双击 `Start-OpenClaw-Hermes.bat`。
2. Mac：打开 U 盘，先双击 `01-双击这里开始.html`，再右键 `Mac-Start.command` 选择“打开”。
3. 启动后，浏览器会自动打开“启动导航”和“配置中心”。配置请在“配置中心”里完成，不要先直接点 `Config.html`。
4. 需要售后时，Windows 双击 `Windows-Support.bat`，Mac 右键 `Mac-Support.command` 选择“打开”，把生成的 `support-bundle-时间.zip` 发给客户服务。
5. 只有需要更新本地 Hermes 模型时，才双击 `Update-Hermes-Model.bat`。这是手动更新，不会随着小版本自动下载 5GB 模型；如果客服没有提醒，当前能正常用就先不用动。

这些词的意思：

- 启动导航：`C-CLAW.html`，负责带你进入控制台、配置中心和支持入口。
- 本地 Hermes：已经放在 U 盘里的 8B Q4 模型，默认不用额外填 API Key；如果模型 hash 变更、出现严重 bug、客服要求更新，或你自己选择刷新时，才运行更新脚本。
- 配置中心：启动后自动打开的模型配置页面。
- 内置额度：店铺赠送的可用额度，先用它最省事。
- 自己 API Key：你自己准备的模型平台 Key，不想充值时可以填。
- 售后支持包：程序自动生成的 zip，给购买店铺客服看日志用。
- 升级源：店铺发布的新版本清单，用来告诉 U 盘是否有新版本。

再提醒一次：

- 不要先直接点 `Config.html`。
- 不要把 API Key、网页登录密码发到群里。
- 客户可见包里不要放 `commercial/`、`gateway-mvp/`、`.git/`、`.env`。
