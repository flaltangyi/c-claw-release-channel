C-CLAW 首次使用说明

请先记住：首批客户按 Windows 路径走。

一、第一次只做 3 步

1. 打开 U 盘根目录，双击 Start-OpenClaw-Hermes.bat。
2. 等待几分钟，黑色窗口不能关闭。
3. 浏览器提示可以进入后，点击“进入本地助手”。

二、看到这些是正常的

- 看到 llama.cpp、11435、http://127.0.0.1:11435，说明 Hermes 本地模型正在启动或已经启动。
- 首次启动较慢，通常需要 1 到 5 分钟，慢电脑可能更久。
- 黑色窗口是本地助手和本地模型的运行窗口，使用过程中不要关闭。
- C-CLAW-Launch.html 是等待页，C-CLAW.html 是导航页。

三、打不开怎么办

1. 先双击 Windows-Diagnose.bat 做健康检查。
2. 仍然打不开，再双击 Windows-Support.bat。
3. 等它生成 data/support/support-bundle-时间.zip。
4. 把这个 zip、订单号、报错截图、卡在哪一步一起发给购买店铺客服。
5. 需要重启时，关闭所有 C-CLAW 黑色窗口，等待 10 秒，再双击 Start-OpenClaw-Hermes.bat。

四、不要做这些

- 不要把 Start-Hermes-Local.bat 当成最终助手入口；它只是本地模型测试入口。
- 不要一上来手动打开 Config.html；请让启动器自动打开配置中心。
- 不要看到 llama.cpp 页面就立刻反复重启。
- 不要关闭黑色窗口，关闭后本地模型和助手会停止。
- 不要单独把支付密码、网页登录密码或 API Key 发给客服。
