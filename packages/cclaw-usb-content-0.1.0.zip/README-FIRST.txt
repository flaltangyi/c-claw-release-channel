C-CLAW 首次打开先看这几条：

1. 这套 U 盘的首批客户路径，以 Windows 为准。Mac/Linux 文件可以保留，但只算兼容或内部验证入口，不是首批客户主路径。
2. 先双击 `01-双击这里开始.html`，再双击 `Start-OpenClaw-Hermes.bat`。
3. 如果你先看到 `llama.cpp`、`11435` 或 `http://127.0.0.1:11435`，这是正常的本地 Hermes 聊天入口，不是 OpenClaw 品牌页出错。
4. 真正改模型、额度和自己的 API Key，要等配置中心自动打开后再操作。
5. 如果只是检查本地模型能不能跑，才用 `Start-Hermes-Local.bat`。
6. 出问题先双击 `Windows-Support.bat`，生成 `data/support/support-bundle-时间.zip`，把这个 zip、订单号和报错截图一起发给客服。

不要做这些事：

- 不要把 `Start-Hermes-Local.bat` 当成最终助手入口。
- 不要一上来就手动点 `Config.html`。
- 不要看到 `llama.cpp` 页面就立刻反复重启。
- 不要把自己的支付密码、网页登录密码或 API Key 单独发给客服。
