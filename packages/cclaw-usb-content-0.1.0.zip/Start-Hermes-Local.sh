#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=portable/Linux-Support.sh
source "$SCRIPT_DIR/Linux-Support.sh"

uclaw_prepare_linux_runtime

model_path="$(uclaw_find_model)" || {
    printf '[ERROR] Missing GGUF model in %s\n' "$MODEL_DIR" >&2
    exit 1
}

uclaw_require_executable "$NODE_BIN" "Node.js runtime"
uclaw_require_executable "$LLAMA_SERVER" "llama.cpp server"

printf '\n'
printf '========================================\n'
printf '  C-CLAW Hermes Local Model (Linux)\n'
printf '========================================\n'
printf '\n'
printf '  model: %s\n' "$model_path"
printf '  endpoint: http://127.0.0.1:%s/v1\n' "$MODEL_PORT"
printf '  first load may take a few minutes.\n'
printf '\n'

exec "$LLAMA_SERVER" -m "$model_path" --host 127.0.0.1 --port "$MODEL_PORT" --alias hermes-local -c 4096 -ngl 0
