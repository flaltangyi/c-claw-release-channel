﻿param(
    [Parameter(Mandatory = $true)]
    [string]$UsbRoot,

    [string]$ManifestUrl = "",

    [string]$SignaturePublicKeyPath = "",

    [switch]$SkipLicenseCheck
)

$ErrorActionPreference = "Stop"
$UsbRoot = (Resolve-Path -LiteralPath $UsbRoot).Path
$CurrentManifestPath = Join-Path $UsbRoot "release-manifest.json"
$UpdateSourcePath = Join-Path $UsbRoot "update-source.txt"
$UpdateDir = Join-Path $UsbRoot "data\updates"
$BackupDir = Join-Path $UsbRoot "data\backups"
$SignatureHelperPath = Join-Path $PSScriptRoot "CClaw-Signature.ps1"
$DefaultSignaturePublicKeyPath = Join-Path $PSScriptRoot "cclaw-update-rsa-v1.xml"
$LicenseHelperPath = Join-Path (Split-Path -Parent $PSScriptRoot) "license\CClaw-License.ps1"

if (-not (Test-Path -LiteralPath $SignatureHelperPath)) {
    throw "Missing signature helper: $SignatureHelperPath"
}
. $SignatureHelperPath

if (-not $SkipLicenseCheck) {
    if (-not (Test-Path -LiteralPath $LicenseHelperPath)) {
        throw "Missing license helper: $LicenseHelperPath"
    }
    . $LicenseHelperPath
}

function Read-JsonFile {
    param([string]$Path)
    return Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
}

function Get-RemoteText {
    param([string]$Source)
    if ($Source -match '^[a-zA-Z]:\\' -or $Source.StartsWith('\\')) {
        return Get-Content -LiteralPath $Source -Raw -Encoding UTF8
    }
    if ($Source -match '^file://') {
        $uri = [Uri]$Source
        return Get-Content -LiteralPath $uri.LocalPath -Raw -Encoding UTF8
    }

    $errors = New-Object System.Collections.ArrayList
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        try {
            return (Invoke-WebRequest -UseBasicParsing -Uri $Source -TimeoutSec 120).Content
        } catch {
            [void]$errors.Add("Invoke-WebRequest attempt $attempt failed: $($_.Exception.Message)")
            Start-Sleep -Seconds ([Math]::Min(10, $attempt * 2))
        }
    }

    $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
    if ($curl) {
        $curlArgs = @(
            "--fail",
            "--location",
            "--show-error",
            "--silent",
            "--retry", "3",
            "--retry-delay", "2",
            "--max-time", "120",
            $Source
        )
        $curlOutput = & $curl.Source @curlArgs 2>&1
        if ($LASTEXITCODE -eq 0) {
            return ($curlOutput | Out-String)
        }
        [void]$errors.Add("curl.exe failed: $(($curlOutput | Out-String).Trim())")
    }

    throw "Failed to read remote text from $Source`n$($errors -join "`n")"
}

function Save-RemoteFile {
    param([string]$Source, [string]$Target)
    if ($Source -match '^[a-zA-Z]:\\' -or $Source.StartsWith('\\')) {
        Copy-Item -LiteralPath $Source -Destination $Target -Force
        return
    }
    if ($Source -match '^file://') {
        $uri = [Uri]$Source
        Copy-Item -LiteralPath $uri.LocalPath -Destination $Target -Force
        return
    }

    $targetDir = Split-Path -Parent $Target
    if (-not [string]::IsNullOrWhiteSpace($targetDir)) {
        New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
    }

    $tempTarget = $Target + ".download"
    $errors = New-Object System.Collections.ArrayList
    for ($attempt = 1; $attempt -le 3; $attempt++) {
        try {
            Remove-Item -LiteralPath $tempTarget -Force -ErrorAction SilentlyContinue
            Invoke-WebRequest -UseBasicParsing -Uri $Source -TimeoutSec 1800 -OutFile $tempTarget
            Move-Item -LiteralPath $tempTarget -Destination $Target -Force
            return
        } catch {
            [void]$errors.Add("Invoke-WebRequest attempt $attempt failed: $($_.Exception.Message)")
            Remove-Item -LiteralPath $tempTarget -Force -ErrorAction SilentlyContinue
            Start-Sleep -Seconds ([Math]::Min(10, $attempt * 2))
        }
    }

    $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
    if ($curl) {
        for ($attempt = 1; $attempt -le 3; $attempt++) {
            Remove-Item -LiteralPath $tempTarget -Force -ErrorAction SilentlyContinue
            $curlArgs = @(
                "--fail",
                "--location",
                "--show-error",
                "--silent",
                "--retry", "3",
                "--retry-delay", "2",
                "--output", $tempTarget,
                $Source
            )
            $curlOutput = & $curl.Source @curlArgs 2>&1
            if ($LASTEXITCODE -eq 0 -and (Test-Path -LiteralPath $tempTarget)) {
                Move-Item -LiteralPath $tempTarget -Destination $Target -Force
                return
            }
            [void]$errors.Add("curl.exe attempt $attempt failed: $(($curlOutput | Out-String).Trim())")
            Remove-Item -LiteralPath $tempTarget -Force -ErrorAction SilentlyContinue
            Start-Sleep -Seconds ([Math]::Min(10, $attempt * 2))
        }
    }

    throw "Failed to download update package from $Source`n$($errors -join "`n")"
}

function Require-Hash {
    param([string]$Path, [string]$Expected)
    if ([string]::IsNullOrWhiteSpace($Expected)) {
        throw "Package hash is empty. Refuse to install unsigned update."
    }
    $actual = (Get-CClawSha256Digest -Path $Path).Hex
    if ($actual -ne $Expected.ToUpperInvariant()) {
        throw "SHA256 mismatch. Expected $Expected but got $actual"
    }
}

function Require-Signature {
    param(
        [Parameter(Mandatory = $true)]
        $Package,

        [Parameter(Mandatory = $true)]
        [string]$PackagePath
    )

    $signatureState = [string]$Package.signatureState
    $signatureAlgorithm = [string]$Package.signatureAlgorithm
    $signatureBase64 = [string]$Package.signatureBase64
    $publicKeyId = [string]$Package.publicKeyId

    if ($signatureState -ne "signed") {
        if ([string]::IsNullOrWhiteSpace($signatureState)) {
            throw "Package signature is missing. Refuse to install unsigned update."
        }
        throw "Package signature state '$signatureState' is not trusted. Refuse to install update."
    }

    if ($signatureAlgorithm -ne "RSA-SHA256") {
        throw "Unsupported package signature algorithm '$signatureAlgorithm'. Expected RSA-SHA256."
    }

    if ([string]::IsNullOrWhiteSpace($signatureBase64)) {
        throw "Package signature is empty. Refuse to install update."
    }

    if ([string]::IsNullOrWhiteSpace($publicKeyId)) {
        throw "Package publicKeyId is empty. Refuse to install update."
    }

    if ([string]::IsNullOrWhiteSpace($SignaturePublicKeyPath)) {
        $SignaturePublicKeyPath = $DefaultSignaturePublicKeyPath
    }

    if (-not (Test-Path -LiteralPath $SignaturePublicKeyPath)) {
        throw "Missing public key file for signature verification: $SignaturePublicKeyPath"
    }

    $expectedPublicKeyId = [System.IO.Path]::GetFileNameWithoutExtension((Resolve-Path -LiteralPath $SignaturePublicKeyPath).Path)
    if ($publicKeyId -ne $expectedPublicKeyId) {
        throw "Package publicKeyId '$publicKeyId' does not match bundled public key '$expectedPublicKeyId'."
    }

    $digest = Get-CClawSha256Digest -Path $PackagePath
    if (-not (Test-CClawRsaSignatureBase64 -PublicKeyPath $SignaturePublicKeyPath -HashBytes $digest.Bytes -SignatureBase64 $signatureBase64)) {
        throw "RSA signature verification failed for package hash."
    }
}

try {
    if (-not (Test-Path -LiteralPath $CurrentManifestPath)) {
        throw "Missing current release-manifest.json in $UsbRoot"
    }

    Write-Host "正在检查授权..."
    if (-not $SkipLicenseCheck) {
        $license = Assert-CClawLicense -UsbRoot $UsbRoot -Purpose "updates"
        Write-Host "  [通过] 授权：$($license.LicenseId) / $($license.Edition) / 更新有效期至 $($license.UpdatesUntil)"
    }

    if ([string]::IsNullOrWhiteSpace($ManifestUrl)) {
        if (Test-Path -LiteralPath $UpdateSourcePath) {
            $ManifestUrl = (Get-Content -LiteralPath $UpdateSourcePath -Raw -Encoding UTF8).Trim()
        }
    }

    if ([string]::IsNullOrWhiteSpace($ManifestUrl)) {
        Write-Host "[提示] 未配置升级源。"
        Write-Host "       请在 update-source.txt 中填写清单地址或本地清单路径。"
        Write-Host "       示例：https://your-domain.example/c-claw/stable.json"
        exit 0
    }

    Write-Host "正在读取升级源..."
    $current = Read-JsonFile $CurrentManifestPath
    $latestText = Get-RemoteText $ManifestUrl
    $latest = $latestText | ConvertFrom-Json

    Write-Host "当前版本：$($current.cclawVersion)"
    Write-Host "最新版本：$($latest.cclawVersion)"
    Write-Host "当前 OpenClaw：$($current.openclawVersion)"
    Write-Host "最新 OpenClaw：$($latest.openclawVersion)"

    if ($latest.cclawVersion -eq $current.cclawVersion -and $latest.openclawVersion -eq $current.openclawVersion) {
        Write-Host "[完成] 当前版本已是最新，无需升级。"
        exit 0
    }

    $package = @($latest.packages | Where-Object { $_.id -eq "cclaw-usb-content" }) | Select-Object -First 1
    if (-not $package -or [string]::IsNullOrWhiteSpace($package.url)) {
        Write-Host "[提示] 已读到最新清单，但尚未配置可安装包地址。"
        Write-Host "       这通常发生在正式发布通道上线前。"
        exit 0
    }

    New-Item -ItemType Directory -Force -Path $UpdateDir, $BackupDir | Out-Null
    $packageFile = Join-Path $UpdateDir ("{0}-{1}.zip" -f $package.id, $package.version)

    Write-Host "[1/6] 正在下载升级包..."
    Save-RemoteFile $package.url $packageFile

    Write-Host "[2/6] 正在校验包体 SHA256..."
    Require-Hash $packageFile $package.sha256

    Write-Host "[3/6] 正在校验数字签名..."
    Require-Signature -Package $package -PackagePath $packageFile

    $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $backupPath = Join-Path $BackupDir "pre-update-$stamp"
    New-Item -ItemType Directory -Force -Path $backupPath | Out-Null

    Write-Host "[4/6] 正在备份当前配置和清单..."
    foreach ($rel in @("release-manifest.json", "C-CLAW_VERSION", "data\.openclaw\openclaw.json")) {
        $src = Join-Path $UsbRoot $rel
        if (Test-Path -LiteralPath $src) {
            $dst = Join-Path $backupPath $rel
            New-Item -ItemType Directory -Force -Path (Split-Path $dst) | Out-Null
            Copy-Item -LiteralPath $src -Destination $dst -Force
        }
    }

    $extractDir = Join-Path $UpdateDir ("extract-" + $stamp)
    New-Item -ItemType Directory -Force -Path $extractDir | Out-Null

    Write-Host "[5/6] 正在解压升级包..."
    Expand-Archive -LiteralPath $packageFile -DestinationPath $extractDir -Force

    $payloadRoot = $extractDir
    $children = Get-ChildItem -LiteralPath $extractDir -Force
    if ($children.Count -eq 1 -and $children[0].PSIsContainer) {
        $payloadRoot = $children[0].FullName
    }

    Write-Host "[6/6] 正在安装升级内容，同时保留 data、models 和 local-model..."
    $excludeDirs = @(
        (Join-Path $payloadRoot "data"),
        (Join-Path $payloadRoot "models"),
        (Join-Path $payloadRoot "local-model")
    )
    robocopy $payloadRoot $UsbRoot /E /XD $excludeDirs /R:2 /W:2 /NP /NFL /NDL /NJH /NJS | Out-Null
    if ($LASTEXITCODE -ge 8) {
        throw "robocopy failed with exit code $LASTEXITCODE"
    }

    Write-Host "[完成] 升级已安装，请重启 C-CLAW 以使用新版本。"
} catch {
    Write-Host ""
    Write-Warning "升级失败。请联系售后并提供支持包，以上保留了具体错误详情。"
    throw
}
