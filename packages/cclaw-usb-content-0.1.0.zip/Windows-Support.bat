@echo off
setlocal
chcp 65001 >nul 2>&1
title C-CLAW - Support Bundle

for %%I in ("%~dp0.") do set "UCLAW_DIR=%%~fI"
set "SCRIPT=%UCLAW_DIR%\support\Collect-SupportBundle.ps1"

echo.
echo   ========================================
echo     C-CLAW Support Bundle
echo   ========================================
echo.

if not exist "%SCRIPT%" (
    echo   Missing script:
    echo   %SCRIPT%
    echo.
    echo   Please re-copy the latest C-CLAW files to this USB.
    echo.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -UClawDir "%UCLAW_DIR%"

echo.
pause
