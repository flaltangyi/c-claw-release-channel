@echo off
title C-CLAW - Start OpenClaw Assistant + Hermes

set "UCLAW_DIR=%~dp0"

echo   Opening C-CLAW navigation page...
start "" "%UCLAW_DIR%C-CLAW.html"

echo.
echo   ========================================
echo     C-CLAW OpenClaw Assistant + Hermes
echo   ========================================
echo.
echo   This path starts Hermes first, then opens the OpenClaw assistant.
echo   If you only want to test the model service, use Start-Hermes-Local.bat.
echo.

set "LICENSE_SCRIPT=%UCLAW_DIR%license\Show-CClawLicense.ps1"
if exist "%LICENSE_SCRIPT%" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%LICENSE_SCRIPT%" -UsbRoot "%UCLAW_DIR%" -Quiet
    if errorlevel 1 (
        echo.
        echo   [WARN] License is missing or invalid. Local startup will continue,
        echo          but official updates, Hermes downloads, and support require a valid license.
        echo.
    )
)

call "%UCLAW_DIR%Configure-Hermes-Local.bat"
if errorlevel 1 exit /b 1

echo   Opening Hermes model service window...
start "C-CLAW Hermes Local Model" cmd /k ""%UCLAW_DIR%Start-Hermes-Local.bat""

echo.
echo   Waiting for local model endpoint...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='http://127.0.0.1:11435/v1/models'; for($i=1; $i -le 90; $i++){ try { Invoke-WebRequest -UseBasicParsing -Uri $u -TimeoutSec 2 | Out-Null; Write-Host '  [OK] Hermes local model is ready'; exit 0 } catch { Start-Sleep -Seconds 2 } }; Write-Host '  [WARN] Hermes model did not become ready in time'; exit 1"

if errorlevel 1 (
    echo.
    echo   [WARN] The model is still loading.
    echo   Wait until the Hermes window says it is ready, then run Windows-Start.bat.
    echo.
    pause
    exit /b 1
)

echo.
echo   Starting OpenClaw assistant...
call "%UCLAW_DIR%Windows-Start.bat"
