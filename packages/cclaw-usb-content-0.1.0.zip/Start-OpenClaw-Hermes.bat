@echo off
title C-CLAW - Start OpenClaw Assistant + Hermes

set "UCLAW_DIR=%~dp0"
for %%I in ("%~dp0.") do set "UCLAW_PS_ROOT=%%~fI"
set "STARTUP_LOG=%UCLAW_DIR%data\logs\startup-openclaw-hermes.log"
if not exist "%UCLAW_DIR%data\logs" mkdir "%UCLAW_DIR%data\logs" >nul 2>&1
>>"%STARTUP_LOG%" echo.
>>"%STARTUP_LOG%" echo ==== Start-OpenClaw-Hermes %DATE% %TIME% ====

echo   Opening C-CLAW assistant launch page...
>>"%STARTUP_LOG%" echo Opening launch page
start "" "%UCLAW_DIR%C-CLAW-Launch.html"

echo.
echo   ========================================
echo     C-CLAW OpenClaw Assistant + Hermes
echo   ========================================
echo.
echo   This path starts Hermes first, then opens the OpenClaw assistant page.
echo   If you only want to test the model service, use Start-Hermes-Local.bat.
echo.

set "LICENSE_SCRIPT=%UCLAW_DIR%license\Show-CClawLicense.ps1"
if exist "%LICENSE_SCRIPT%" (
    >>"%STARTUP_LOG%" echo Checking license
    powershell -NoProfile -ExecutionPolicy Bypass -File "%LICENSE_SCRIPT%" -UsbRoot "%UCLAW_PS_ROOT%" -Quiet
    if errorlevel 1 (
        echo.
        echo   [WARN] License is missing or invalid. Local startup will continue,
        echo          but official updates, Hermes downloads, and support require a valid license.
        echo.
    )
)

>>"%STARTUP_LOG%" echo Configuring Hermes local model
call "%UCLAW_DIR%Configure-Hermes-Local.bat"
if errorlevel 1 exit /b 1

echo   Opening Hermes model service window...
>>"%STARTUP_LOG%" echo Starting Hermes window
start "C-CLAW Hermes Local Model" cmd /k ""%UCLAW_DIR%Start-Hermes-Assistant.bat""

echo.
echo   Hermes is starting in its own window.
echo   OpenClaw will start now; the launch page waits until both are ready.
>>"%STARTUP_LOG%" echo Continuing without blocking on Hermes readiness

echo.
echo   Starting OpenClaw assistant...
>>"%STARTUP_LOG%" echo Calling Windows-Start.bat
set "C_CLAW_ALLOW_MODEL_LOADING=1"
call "%UCLAW_DIR%Windows-Start.bat"
>>"%STARTUP_LOG%" echo Windows-Start.bat returned errorlevel %ERRORLEVEL%
