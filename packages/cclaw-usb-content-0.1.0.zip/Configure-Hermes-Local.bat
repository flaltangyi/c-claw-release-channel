@echo off
title C-CLAW - Configure Hermes Local

set "UCLAW_DIR=%~dp0"
set "DATA_DIR=%UCLAW_DIR%data"
set "STATE_DIR=%DATA_DIR%\.openclaw"
set "CONFIG_PATH=%STATE_DIR%\openclaw.json"
set "NODE_BIN=%UCLAW_DIR%app\runtime\node-win-x64\node.exe"

if not exist "%NODE_BIN%" (
    echo.
    echo   [ERROR] Missing Node.js runtime.
    echo   Please run setup.bat or re-copy the C-CLAW USB package.
    echo.
    pause
    exit /b 1
)

if not exist "%STATE_DIR%" mkdir "%STATE_DIR%" >nul 2>&1
if not exist "%DATA_DIR%\logs" mkdir "%DATA_DIR%\logs" >nul 2>&1
if exist "%CONFIG_PATH%" (
    for /f "tokens=1-4 delims=/-. " %%a in ("%date% %time%") do set "STAMP=%%a%%b%%c_%%d"
    copy "%CONFIG_PATH%" "%STATE_DIR%\openclaw.before-hermes.%STAMP%.json" >nul 2>&1
)

"%NODE_BIN%" "%UCLAW_DIR%lib\configure-hermes-local.mjs" "%CONFIG_PATH%"
if errorlevel 1 (
    echo.
    echo   [ERROR] Failed to write Hermes local model config.
    echo   Please run Windows-Support.bat and send the support bundle to support.
    echo.
    pause
    exit /b 1
)

echo.
echo   [OK] OpenClaw default model is now local Hermes.
echo   Local model endpoint: http://127.0.0.1:11435/v1
echo.
