@echo off
setlocal
chcp 65001 >nul 2>&1
title C-CLAW - License Status

for %%I in ("%~dp0.") do set "UCLAW_DIR=%%~fI"
set "SCRIPT=%UCLAW_DIR%\license\Show-CClawLicense.ps1"

if not exist "%SCRIPT%" (
    echo Missing license status script:
    echo %SCRIPT%
    echo.
    pause
    exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT%" -UsbRoot "%UCLAW_DIR%"
set "RC=%ERRORLEVEL%"

echo.
pause
exit /b %RC%
