param(
    [string]$UsbRoot = (Resolve-Path (Join-Path $PSScriptRoot "..")).Path,
    [int]$PortStart = 18789,
    [int]$PortEnd = 18799,
    [int]$TimeoutSec = 3,
    [switch]$NoOpenBrowser
)

$ErrorActionPreference = "Stop"

function Get-CommandLine {
    param([int]$ProcessId)

    try {
        $proc = Get-CimInstance Win32_Process -Filter "ProcessId = $ProcessId"
        if ($proc) {
            return [string]$proc.CommandLine
        }
    } catch {
        return ""
    }
    return ""
}

function Test-OpenClawHttp {
    param([int]$Port)

    try {
        Invoke-WebRequest -UseBasicParsing -Uri "http://127.0.0.1:$Port/" -TimeoutSec $TimeoutSec | Out-Null
        return $true
    } catch {
        return $false
    }
}

$normalizedRoot = [System.IO.Path]::GetFullPath($UsbRoot).TrimEnd("\", "/")
$normalizedRootLower = $normalizedRoot.ToLowerInvariant()
$expectedGatewayEntryLower = (Join-Path $normalizedRoot "app\core\node_modules\openclaw\openclaw.mjs").ToLowerInvariant()

Write-Host "  Checking existing OpenClaw gateway ports $PortStart-$PortEnd..."

$connections = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
    Where-Object { $_.LocalPort -ge $PortStart -and $_.LocalPort -le $PortEnd } |
    Sort-Object LocalPort)

$seenPids = @{}
foreach ($connection in $connections) {
    $processId = [int]$connection.OwningProcess
    if ($seenPids.ContainsKey($processId)) {
        continue
    }
    $seenPids[$processId] = $true

    $commandLine = Get-CommandLine -ProcessId $processId
    if ([string]::IsNullOrWhiteSpace($commandLine)) {
        continue
    }

    $commandLower = $commandLine.ToLowerInvariant()
    $isOpenClawGateway = $commandLower.Contains("gateway run") -and $commandLower.Contains($expectedGatewayEntryLower)
    $isThisUsb = $commandLower.Contains($normalizedRootLower)

    if (-not ($isOpenClawGateway -and $isThisUsb)) {
        continue
    }

    $port = [int]$connection.LocalPort
    if (Test-OpenClawHttp -Port $port) {
        Write-Host "  [OK] Existing OpenClaw gateway is healthy on port $port (PID $processId)."
        if (-not $NoOpenBrowser) {
            Start-Process "http://127.0.0.1:$port/#token=uclaw"
        }
        exit 10
    }

    Write-Host "  [FIX] Stopping stale OpenClaw gateway on port $port (PID $processId)."
    Write-Host "       $commandLine"
    try {
        Stop-Process -Id $processId -Force -ErrorAction Stop
    } catch {
        Write-Warning ("Failed to stop PID {0}: {1}" -f $processId, $_.Exception.Message)
    }
}

exit 0
