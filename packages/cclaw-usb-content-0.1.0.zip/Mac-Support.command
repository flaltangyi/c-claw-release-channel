#!/bin/bash
# C-CLAW Support Bundle - macOS

set -u

UCLAW_DIR="$(cd "$(dirname "$0")" && pwd)"
DATA_DIR="$UCLAW_DIR/data"
STATE_DIR="$DATA_DIR/.openclaw"
LOG_DIR="$DATA_DIR/logs"
SUPPORT_DIR="$DATA_DIR/support"

ARCH="$(uname -m)"
if [ "$ARCH" = "arm64" ]; then
  NODE_BIN="$UCLAW_DIR/app/runtime/node-mac-arm64/bin/node"
else
  NODE_BIN="$UCLAW_DIR/app/runtime/node-mac-x64/bin/node"
fi
CORE_DIR="$UCLAW_DIR/app/core"
OPENCLAW_MJS="$CORE_DIR/node_modules/openclaw/openclaw.mjs"

mkdir -p "$SUPPORT_DIR"
TS="$(date +%Y%m%d_%H%M%S)"
BUNDLE_DIR="$SUPPORT_DIR/support-bundle-$TS"
mkdir -p "$BUNDLE_DIR"

echo ""
echo "  ========================================"
echo "    C-CLAW Support Bundle"
echo "  ========================================"
echo ""
echo "  这个工具会收集诊断信息，方便客服定位问题。"
echo "  API Key 和 token 会尽量隐藏。"
echo ""

echo "[1/7] Collecting system info..."
{
  echo "C-CLAW Support Bundle"
  echo "Generated: $(date)"
  echo "UCLAW_DIR: $UCLAW_DIR"
  echo "USER: $USER"
  echo ""
  echo "System Info"
  echo "==========="
  sw_vers 2>/dev/null || true
  uname -a
  echo ""
  echo "Disk:"
  df -h "$UCLAW_DIR" 2>/dev/null || true
} > "$BUNDLE_DIR/support-summary.txt"

echo "[2/7] Checking runtime..."
{
  echo "Runtime Check"
  echo "============="
  echo "NODE_BIN=$NODE_BIN"
  if [ -x "$NODE_BIN" ]; then
    "$NODE_BIN" --version 2>&1
  else
    echo "MISSING_NODE"
  fi
  echo ""
  echo "CORE_DIR=$CORE_DIR"
  [ -d "$CORE_DIR" ] && echo "CORE_EXISTS" || echo "MISSING_CORE"
  if [ -f "$OPENCLAW_MJS" ]; then
    echo "OPENCLAW_MJS_EXISTS"
    [ -x "$NODE_BIN" ] && "$NODE_BIN" "$OPENCLAW_MJS" --version 2>&1 || true
  else
    echo "MISSING_OPENCLAW_MJS"
  fi
} > "$BUNDLE_DIR/runtime-check.txt"

echo "[3/7] Checking ports and processes..."
{
  echo "Port Check"
  echo "=========="
  for port in $(seq 18789 18799); do
    lsof -nP -iTCP:"$port" -sTCP:LISTEN 2>/dev/null || true
  done
  echo ""
  echo "OpenClaw Processes"
  echo "=================="
  ps aux | grep -i "openclaw\|node" | grep -v grep || true
} > "$BUNDLE_DIR/processes.txt"

echo "[4/7] Redacting config..."
if [ -f "$STATE_DIR/openclaw.json" ]; then
  python3 - "$STATE_DIR/openclaw.json" "$BUNDLE_DIR/openclaw.sanitized.json" <<'PY'
import json, re, sys
src, dst = sys.argv[1], sys.argv[2]
try:
    data = json.load(open(src, encoding="utf-8"))
    def redact(obj):
        if isinstance(obj, dict):
            return {k: ("***REDACTED***" if re.search(r"(apiKey|token|secret|password|appSecret|authorization)", k, re.I) else redact(v)) for k, v in obj.items()}
        if isinstance(obj, list):
            return [redact(x) for x in obj]
        return obj
    json.dump(redact(data), open(dst, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
except Exception as exc:
    open(dst, "w", encoding="utf-8").write(f"Could not parse config: {exc}\n")
PY
else
  echo "Config not found" > "$BUNDLE_DIR/openclaw.sanitized.json"
fi

echo "[5/7] Copying diagnostic and log tails..."
[ -f "$UCLAW_DIR/diagnostic-log.txt" ] && cp "$UCLAW_DIR/diagnostic-log.txt" "$BUNDLE_DIR/diagnostic-log.txt"
if [ -f "$LOG_DIR/gateway.log" ]; then
  tail -200 "$LOG_DIR/gateway.log" > "$BUNDLE_DIR/gateway-log-tail.txt"
else
  echo "gateway.log not found" > "$BUNDLE_DIR/gateway-log-tail.txt"
fi

echo "[6/7] Checking network..."
{
  echo "Network Check"
  echo "============="
  for url in \
    "https://registry.npmmirror.com/openclaw/latest" \
    "https://api.u-claw.org/v1/models" \
    "https://api.deepseek.com"; do
    if command -v curl >/dev/null 2>&1; then
      code="$(curl --noproxy '*' -L -m 8 -o /dev/null -s -w '%{http_code}' "$url" || true)"
      echo "$url -> HTTP $code"
    else
      echo "$url -> curl not available"
    fi
  done
} > "$BUNDLE_DIR/network-check.txt"

echo "[7/7] Creating zip..."
ZIP_FILE="$SUPPORT_DIR/support-bundle-$TS.zip"
(cd "$BUNDLE_DIR" && zip -qr "$ZIP_FILE" .)

echo ""
echo "  ========================================"
echo "    售后支持包已生成"
echo "  ========================================"
echo ""
echo "  ZIP: $ZIP_FILE"
echo ""
echo "  请把这个 zip 文件、订单号、报错截图一起发给客服。"
echo "  请不要单独发送支付密码、网页登录密码或模型 API Key。"
echo ""
read -p "  按回车退出..."
