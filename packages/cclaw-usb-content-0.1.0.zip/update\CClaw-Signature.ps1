function Get-CClawSha256Digest {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (-not (Test-Path -LiteralPath $Path)) {
        throw "Missing file for SHA256 digest: $Path"
    }

    $stream = [System.IO.File]::Open($Path, [System.IO.FileMode]::Open, [System.IO.FileAccess]::Read, [System.IO.FileShare]::Read)
    try {
        $sha256 = [System.Security.Cryptography.SHA256]::Create()
        try {
            $bytes = $sha256.ComputeHash($stream)
        } finally {
            $sha256.Dispose()
        }
    } finally {
        $stream.Dispose()
    }

    $hex = ($bytes | ForEach-Object { $_.ToString("X2") }) -join ""
    return [pscustomobject]@{
        Bytes = $bytes
        Hex   = $hex
    }
}

function ConvertTo-CClawRsaProvider {
    param(
        [Parameter(Mandatory = $true)]
        [string]$XmlPath
    )

    if (-not (Test-Path -LiteralPath $XmlPath)) {
        throw "Missing RSA XML key: $XmlPath"
    }

    $xml = Get-Content -LiteralPath $XmlPath -Raw -Encoding UTF8
    if ([string]::IsNullOrWhiteSpace($xml)) {
        throw "RSA XML key is empty: $XmlPath"
    }

    $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider
    try {
        $rsa.PersistKeyInCsp = $false
        $rsa.FromXmlString($xml)
        return $rsa
    } catch {
        $rsa.Dispose()
        throw "Failed to import RSA XML key '$XmlPath': $($_.Exception.Message)"
    }
}

function New-CClawRsaSignatureBase64 {
    param(
        [Parameter(Mandatory = $true)]
        [string]$PrivateKeyPath,

        [Parameter(Mandatory = $true)]
        [byte[]]$HashBytes
    )

    $rsa = ConvertTo-CClawRsaProvider -XmlPath $PrivateKeyPath
    try {
        $oid = [System.Security.Cryptography.CryptoConfig]::MapNameToOID("SHA256")
        $signature = $rsa.SignHash($HashBytes, $oid)
        return [Convert]::ToBase64String($signature)
    } finally {
        $rsa.Dispose()
    }
}

function Test-CClawRsaSignatureBase64 {
    param(
        [Parameter(Mandatory = $true)]
        [string]$PublicKeyPath,

        [Parameter(Mandatory = $true)]
        [byte[]]$HashBytes,

        [Parameter(Mandatory = $true)]
        [string]$SignatureBase64
    )

    $rsa = ConvertTo-CClawRsaProvider -XmlPath $PublicKeyPath
    try {
        $oid = [System.Security.Cryptography.CryptoConfig]::MapNameToOID("SHA256")
        $signatureBytes = [Convert]::FromBase64String($SignatureBase64)
        return $rsa.VerifyHash($HashBytes, $oid, $signatureBytes)
    } finally {
        $rsa.Dispose()
    }
}
