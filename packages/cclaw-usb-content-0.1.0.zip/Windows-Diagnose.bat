@echo off
setlocal EnableExtensions EnableDelayedExpansion
title C-CLAW Diagnostic

set "UCLAW_DIR=%~dp0"
set "LOG_FILE=%UCLAW_DIR%diagnostic-log.txt"
set "NODE_BIN=%UCLAW_DIR%app\runtime\node-win-x64\node.exe"
set "MODEL_DIR=%UCLAW_DIR%models"
set "LLAMA_DIR=%UCLAW_DIR%local-model\llama.cpp"
set "LLAMA_SERVER=%LLAMA_DIR%\llama-server.exe"
set "STATE_DIR=%UCLAW_DIR%data\.openclaw"
set "CONFIG_FILE=%STATE_DIR%\openclaw.json"
set "MODEL_PORT=11435"
set "CONFIG_PORT=18788"
set "GATEWAY_PORT_START=18789"
set "GATEWAY_PORT_END=18799"
set "ERROR_COUNT=0"
set "WARN_COUNT=0"

echo.
echo   ========================================
echo     C-CLAW Diagnostic
echo   ========================================
echo.
echo   Checking model files, Node, llama-server, ports, and OpenClaw config.
echo.

> "%LOG_FILE%" (
    echo C-CLAW Diagnostic Report
    echo Generated: %date% %time%
    echo Root: %UCLAW_DIR%
    echo.
)

call :check_node
call :check_model
call :check_llama
call :check_config
call :check_ports
call :summary

if defined UCLAW_NO_PAUSE exit /b 0
pause
exit /b 0

:log
>> "%LOG_FILE%" echo %*
goto :eof

:check_node
echo [1/5] Node runtime
call :log [1/5] Node runtime
if exist "%NODE_BIN%" (
    set "NODE_VERSION="
    for /f "usebackq delims=" %%v in (`"%NODE_BIN%" --version 2^>^&1`) do set "NODE_VERSION=%%v"
    if defined NODE_VERSION (
        echo   OK  Node: !NODE_VERSION!
        call :log OK Node !NODE_VERSION!
    ) else (
        echo   WARN Node exists but version was not returned.
        call :log WARN Node exists but version was not returned
        set /a WARN_COUNT+=1
    )
) else (
    echo   FAIL Missing Node: %NODE_BIN%
    call :log FAIL Missing Node %NODE_BIN%
    set /a ERROR_COUNT+=1
)
echo.
goto :eof

:check_model
echo [2/5] Hermes model files
call :log [2/5] Hermes model files
set "MODEL_FILE="
for /f "delims=" %%m in ('dir /b /a-d "%MODEL_DIR%\Hermes-*.gguf" 2^>nul') do (
    if not defined MODEL_FILE set "MODEL_FILE=%%m"
)
if defined MODEL_FILE (
    echo   OK  Model: !MODEL_FILE!
    call :log OK Model !MODEL_FILE!
) else (
    echo   FAIL Missing model under: %MODEL_DIR%
    call :log FAIL Missing Hermes model under %MODEL_DIR%
    set /a ERROR_COUNT+=1
)
if exist "%LLAMA_SERVER%" (
    echo   OK  llama-server.exe found
    call :log OK llama-server %LLAMA_SERVER%
) else (
    echo   FAIL Missing llama-server.exe: %LLAMA_SERVER%
    call :log FAIL Missing llama-server %LLAMA_SERVER%
    set /a ERROR_COUNT+=1
)
echo.
goto :eof

:check_llama
echo [3/5] Local Hermes service
call :log [3/5] Local Hermes service
set "LLAMA_PID="
for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":%MODEL_PORT% " ^| findstr "LISTENING" 2^>nul') do set "LLAMA_PID=%%p"
if defined LLAMA_PID (
    echo   OK  Port %MODEL_PORT% is listening. PID !LLAMA_PID!
    call :log OK Port %MODEL_PORT% listening PID !LLAMA_PID!
) else (
    echo   WARN Port %MODEL_PORT% is not listening.
    echo        Run Start-Hermes-Local.bat before using local Hermes.
    call :log WARN Port %MODEL_PORT% not listening
    set /a WARN_COUNT+=1
)
echo.
goto :eof

:check_config
echo [4/5] OpenClaw config
call :log [4/5] OpenClaw config
if exist "%CONFIG_FILE%" (
    echo   OK  Config file: %CONFIG_FILE%
    call :log OK Config file %CONFIG_FILE%
    findstr /i /c:"hermes-local" /c:"11435" "%CONFIG_FILE%" >nul 2>&1
    if not errorlevel 1 (
        echo   OK  Config references local Hermes.
        call :log OK Config references local Hermes
    ) else (
        echo   WARN Config exists but does not reference local Hermes.
        echo        Open Config.html and save the local Hermes settings once.
        call :log WARN Config does not reference local Hermes
        set /a WARN_COUNT+=1
    )
) else (
    echo   WARN Config file not created yet: %CONFIG_FILE%
    echo        First startup can create it automatically.
    call :log WARN Missing config %CONFIG_FILE%
    set /a WARN_COUNT+=1
)
echo.
goto :eof

:check_ports
echo [5/5] Port status
call :log [5/5] Port status
call :check_one_port %CONFIG_PORT% "Config center"
for /l %%p in (%GATEWAY_PORT_START%,1,%GATEWAY_PORT_END%) do call :check_gateway_port %%p
echo.
goto :eof

:check_one_port
set "CHECK_PID="
for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":%~1 " ^| findstr "LISTENING" 2^>nul') do set "CHECK_PID=%%p"
if defined CHECK_PID (
    echo   INFO %~2 port %~1 is listening. PID !CHECK_PID!
    call :log INFO %~2 port %~1 listening PID !CHECK_PID!
) else (
    echo   INFO %~2 port %~1 is free.
    call :log INFO %~2 port %~1 free
)
goto :eof

:check_gateway_port
set "GW_PID="
for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":%~1 " ^| findstr "LISTENING" 2^>nul') do set "GW_PID=%%p"
if defined GW_PID (
    echo   INFO Gateway port %~1 is listening. PID !GW_PID!
    call :log INFO Gateway port %~1 listening PID !GW_PID!
)
goto :eof

:summary
echo   ========================================
echo     Result
echo   ========================================
echo.
if !ERROR_COUNT! EQU 0 (
    echo   PASS No fatal issue found.
) else (
    echo   FAIL !ERROR_COUNT! fatal issue count found.
)
if !WARN_COUNT! GTR 0 echo   WARN !WARN_COUNT! warning count found.
echo.
echo   Next steps:
echo   - Model not running: start Start-Hermes-Local.bat.
echo   - Config not local Hermes: open Config.html and save local Hermes once.
echo   - Gateway looks stuck: run Windows-Menu.bat then choose D Repair.
echo   - Need support: run Windows-Support.bat and send the support zip.
echo.
echo   Log saved: %LOG_FILE%
call :log Result errors=!ERROR_COUNT! warnings=!WARN_COUNT!
goto :eof
