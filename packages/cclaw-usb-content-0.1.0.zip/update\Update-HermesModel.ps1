﻿param(
    [Parameter(Mandatory = $true)]
    [string]$UsbRoot,

    [string]$ManifestUrl = "",

    [switch]$SkipLicenseCheck
)

$ErrorActionPreference = "Stop"

$UsbRoot = (Resolve-Path -LiteralPath $UsbRoot).Path
$RootManifestPath = Join-Path $UsbRoot "release-manifest.json"
$ModelUpdateDir = Join-Path $UsbRoot "data\model-updates"
$LicenseHelperPath = Join-Path (Split-Path -Parent $PSScriptRoot) "license\CClaw-License.ps1"

if (-not $SkipLicenseCheck) {
    if (-not (Test-Path -LiteralPath $LicenseHelperPath)) {
        throw "Missing license helper: $LicenseHelperPath"
    }
    . $LicenseHelperPath
}

function Read-JsonFile {
    param([string]$Path)
    return Get-Content -LiteralPath $Path -Raw -Encoding UTF8 | ConvertFrom-Json
}

function Get-SourcePayload {
    param([string]$Source)

    if ([string]::IsNullOrWhiteSpace($Source)) {
        throw "Source reference is empty."
    }

    if (Test-Path -LiteralPath $Source) {
        $resolved = (Resolve-Path -LiteralPath $Source).Path
        return [pscustomobject]@{
            Source = $resolved
            Text   = Get-Content -LiteralPath $resolved -Raw -Encoding UTF8
        }
    }

    if ($Source -match '^file://') {
        $uri = [Uri]$Source
        $resolved = $uri.LocalPath
        return [pscustomobject]@{
            Source = $resolved
            Text   = Get-Content -LiteralPath $resolved -Raw -Encoding UTF8
        }
    }

    $response = Invoke-WebRequest -UseBasicParsing -Uri $Source -TimeoutSec 120
    return [pscustomobject]@{
        Source = $Source
        Text   = $response.Content
    }
}

function Resolve-Reference {
    param(
        [string]$BaseSource,
        [string]$Reference
    )

    if ([string]::IsNullOrWhiteSpace($Reference)) {
        return $null
    }

    if ($Reference -match '^[a-zA-Z]:\\' -or $Reference.StartsWith('\\')) {
        return $Reference
    }

    if ($Reference -match '^file://') {
        return ([Uri]$Reference).LocalPath
    }

    if ($Reference -match '^https?://') {
        return $Reference
    }

    if ($BaseSource -match '^[a-zA-Z]:\\' -or $BaseSource.StartsWith('\\')) {
        return (Join-Path (Split-Path -Parent $BaseSource) $Reference)
    }

    if ($BaseSource -match '^file://') {
        $baseLocal = ([Uri]$BaseSource).LocalPath
        return (Join-Path (Split-Path -Parent $baseLocal) $Reference)
    }

    if ($BaseSource -match '^https?://') {
        return ([Uri]::new([Uri]$BaseSource, ($Reference -replace '\\', '/'))).AbsoluteUri
    }

    return $Reference
}

function Get-FirstPropertyValue {
    param(
        [object]$Object,
        [string[]]$Names
    )

    foreach ($name in $Names) {
        if ($null -ne $Object -and $Object.PSObject.Properties.Name -contains $name) {
            $value = $Object.$name
            if ($null -ne $value -and -not [string]::IsNullOrWhiteSpace([string]$value)) {
                return $value
            }
        }
    }

    return $null
}

function Get-ModelManifestUrl {
    param([object]$Manifest)

    $candidate = Get-FirstPropertyValue $Manifest @("modelManifestUrl", "modelManifestPath")
    if ($candidate) {
        return [string]$candidate
    }

    if ($Manifest.PSObject.Properties.Name -contains "model" -and $null -ne $Manifest.model) {
        $candidate = Get-FirstPropertyValue $Manifest.model @("manifestUrl", "manifestPath")
        if ($candidate) {
            return [string]$candidate
        }
    }

    if ($Manifest.PSObject.Properties.Name -contains "models" -and $null -ne $Manifest.models) {
        $first = @($Manifest.models) | Select-Object -First 1
        $candidate = Get-FirstPropertyValue $first @("manifestUrl", "manifestPath")
        if ($candidate) {
            return [string]$candidate
        }
    }

    return $null
}

function Select-ModelEntry {
    param(
        [object]$Manifest,
        [string]$PreferredModelId
    )

    if ($Manifest.PSObject.Properties.Name -contains "model" -and $null -ne $Manifest.model) {
        return $Manifest.model
    }

    if ($Manifest.PSObject.Properties.Name -contains "models" -and $null -ne $Manifest.models) {
        $models = @($Manifest.models)
        if ($PreferredModelId) {
            $matched = $models | Where-Object { $_.id -eq $PreferredModelId } | Select-Object -First 1
            if ($matched) {
                return $matched
            }
        }

        return $models | Select-Object -First 1
    }

    return $Manifest
}

function Get-Int64Value {
    param(
        [object]$Object,
        [string[]]$Names
    )

    $value = Get-FirstPropertyValue $Object $Names
    if ($null -eq $value) {
        return $null
    }

    try {
        return [int64]$value
    } catch {
        throw "Invalid integer value '$value' for fields: $($Names -join ', ')"
    }
}

function Resolve-TargetPath {
    param(
        [string]$UsbRootValue,
        [object]$ModelEntry
    )

    $targetPath = Get-FirstPropertyValue $ModelEntry @("targetPath")
    $fileName = Get-FirstPropertyValue $ModelEntry @("fileName", "name")

    if ($targetPath) {
        $targetPath = [string]$targetPath
        if ($targetPath -match '^[a-zA-Z]:\\' -or $targetPath.StartsWith('\\')) {
            return $targetPath
        }
        return (Join-Path $UsbRootValue $targetPath)
    }

    if ($fileName) {
        return (Join-Path (Join-Path $UsbRootValue "models") ([string]$fileName))
    }

    throw "Model manifest did not provide targetPath or fileName."
}

function Get-DriveFreeBytes {
    param([string]$Path)

    $root = [System.IO.Path]::GetPathRoot($Path)
    if ([string]::IsNullOrWhiteSpace($root)) {
        throw "Cannot determine drive root for $Path"
    }

    $driveInfo = New-Object System.IO.DriveInfo($root)
    return [int64]$driveInfo.AvailableFreeSpace
}

function Get-ReadableBytes {
    param([int64]$Bytes)

    if ($Bytes -ge 1TB) {
        return ("{0:N2} TB" -f ($Bytes / 1TB))
    }
    if ($Bytes -ge 1GB) {
        return ("{0:N2} GB" -f ($Bytes / 1GB))
    }
    if ($Bytes -ge 1MB) {
        return ("{0:N2} MB" -f ($Bytes / 1MB))
    }
    return ("{0:N0} B" -f $Bytes)
}

function Invoke-RemoteDownload {
    param(
        [string]$SourceUrl,
        [string]$TargetPath
    )

    $curl = Get-Command curl.exe -ErrorAction SilentlyContinue
    if ($curl) {
        $curlArgs = @(
            "--fail",
            "--location",
            "--show-error",
            "--silent",
            "--retry", "3",
            "--retry-delay", "2",
            "--continue-at", "-",
            "--output", $TargetPath,
            $SourceUrl
        )

        $previousErrorActionPreference = $ErrorActionPreference
        $ErrorActionPreference = "Continue"
        try {
            $curlOutput = & $curl.Source @curlArgs 2>&1
            $curlExitCode = $LASTEXITCODE
        } finally {
            $ErrorActionPreference = $previousErrorActionPreference
        }

        if ($curlExitCode -eq 0) {
            return
        }

        $detailLines = @(
            foreach ($item in @($curlOutput)) {
                if ($item -is [System.Management.Automation.ErrorRecord]) {
                    $item.Exception.Message
                } else {
                    [string]$item
                }
            }
        )
        $detail = ($detailLines -join "`n").Trim()
        if (-not [string]::IsNullOrWhiteSpace($detail)) {
            Write-Warning "curl.exe 下载失败，改用 PowerShell 下载兜底：$detail"
        } else {
            Write-Warning "curl.exe 下载失败，改用 PowerShell 下载兜底。exit=$curlExitCode"
        }
    } else {
        Write-Warning "未找到 curl.exe，改用 PowerShell 下载。"
    }

    Invoke-DotNetRemoteDownload -SourceUrl $SourceUrl -TargetPath $TargetPath
}

function Invoke-DotNetRemoteDownload {
    param(
        [string]$SourceUrl,
        [string]$TargetPath
    )

    $existingBytes = 0
    if (Test-Path -LiteralPath $TargetPath) {
        $existingBytes = (Get-Item -LiteralPath $TargetPath).Length
    }

    $request = [System.Net.HttpWebRequest]::Create($SourceUrl)
    $request.Method = "GET"
    $request.UserAgent = "Mozilla/5.0"
    $request.AllowAutoRedirect = $true
    $request.Timeout = 60000
    $request.ReadWriteTimeout = 60000
    if ($existingBytes -gt 0) {
        $request.AddRange($existingBytes)
    }

    $response = $null
    $stream = $null
    $fileStream = $null
    try {
        $response = $request.GetResponse()
        $statusCode = [int]$response.StatusCode
        $append = ($existingBytes -gt 0 -and $statusCode -eq 206)
        if ($existingBytes -gt 0 -and -not $append) {
            Write-Warning "下载源未按 Range 续传，重新从头下载。HTTP $statusCode"
            $existingBytes = 0
        }

        $fileMode = [System.IO.FileMode]::Create
        if ($append) {
            $fileMode = [System.IO.FileMode]::Append
        }

        $stream = $response.GetResponseStream()
        $fileStream = [System.IO.File]::Open($TargetPath, $fileMode, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
        $buffer = New-Object byte[] (4MB)
        while ($true) {
            $read = $stream.Read($buffer, 0, $buffer.Length)
            if ($read -le 0) {
                break
            }
            $fileStream.Write($buffer, 0, $read)
        }
    } catch {
        throw "Failed to download Hermes model from $SourceUrl with PowerShell fallback`n$($_.Exception.Message)"
    } finally {
        if ($fileStream) { $fileStream.Dispose() }
        if ($stream) { $stream.Dispose() }
        if ($response) { $response.Dispose() }
    }
}

function Add-DownloadSource {
    param(
        [System.Collections.ArrayList]$Sources,
        [string]$SourceUrl,
        [string]$Role
    )

    if ([string]::IsNullOrWhiteSpace($SourceUrl)) {
        return
    }

    $trimmed = $SourceUrl.Trim()
    foreach ($source in $Sources) {
        if ([string]::Equals([string]$source.Url, $trimmed, [System.StringComparison]::OrdinalIgnoreCase)) {
            return
        }
    }

    [void]$Sources.Add([pscustomobject]@{
        Url  = $trimmed
        Role = $Role
    })
}

function Add-DownloadSourceValues {
    param(
        [System.Collections.ArrayList]$Sources,
        [object]$Value,
        [string]$Role
    )

    if ($null -eq $Value) {
        return
    }

    foreach ($item in @($Value)) {
        if ($null -eq $item) {
            continue
        }

        if ($item -is [string]) {
            Add-DownloadSource -Sources $Sources -SourceUrl $item -Role $Role
            continue
        }

        $candidate = Get-FirstPropertyValue $item @("url", "downloadUrl", "sourceUrl", "source", "href")
        if ($candidate) {
            Add-DownloadSource -Sources $Sources -SourceUrl ([string]$candidate) -Role $Role
        }
    }
}

function Get-ModelDownloadSources {
    param([object]$ModelEntry)

    $sources = New-Object System.Collections.ArrayList
    $primary = Get-FirstPropertyValue $ModelEntry @("url", "downloadUrl", "sourceUrl")
    if (-not $primary) {
        $primary = Get-FirstPropertyValue $ModelEntry @("source")
    }

    Add-DownloadSource -Sources $sources -SourceUrl ([string]$primary) -Role "primary"

    foreach ($name in @("downloadMirrors", "mirrors", "mirrorUrls", "fallbackUrls", "urls")) {
        if ($ModelEntry.PSObject.Properties.Name -contains $name) {
            Add-DownloadSourceValues -Sources $sources -Value $ModelEntry.$name -Role $name
        }
    }

    return @($sources)
}

function Test-LocalSourceReference {
    param([string]$SourceUrl)

    return ($SourceUrl -match '^[a-zA-Z]:\\' -or $SourceUrl.StartsWith('\\') -or $SourceUrl -match '^file://')
}

function Resolve-LocalSourcePath {
    param([string]$SourceUrl)

    if ($SourceUrl -match '^file://') {
        return ([Uri]$SourceUrl).LocalPath
    }

    return $SourceUrl
}

function Invoke-LocalCopy {
    param(
        [string]$SourcePath,
        [string]$TargetPath
    )

    Copy-Item -LiteralPath $SourcePath -Destination $TargetPath -Force
}

function Test-HermesModelPart {
    param(
        [string]$PartPath,
        [int64]$ExpectedSizeBytes,
        [string]$ExpectedSha256
    )

    if (-not (Test-Path -LiteralPath $PartPath)) {
        return [pscustomobject]@{
            Ok      = $false
            Message = "Part file was not created."
            Hash    = $null
        }
    }

    $partInfo = Get-Item -LiteralPath $PartPath
    if ($partInfo.Length -ne $ExpectedSizeBytes) {
        return [pscustomobject]@{
            Ok      = $false
            Message = "Downloaded part file size mismatch. Expected $ExpectedSizeBytes bytes but got $($partInfo.Length) bytes."
            Hash    = $null
        }
    }

    $partHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $PartPath).Hash.ToUpperInvariant()
    if ($partHash -ne $ExpectedSha256.ToUpperInvariant()) {
        return [pscustomobject]@{
            Ok      = $false
            Message = "SHA256 mismatch for Hermes model. Expected $($ExpectedSha256.ToUpperInvariant()) but got $partHash."
            Hash    = $partHash
        }
    }

    return [pscustomobject]@{
        Ok      = $true
        Message = "OK"
        Hash    = $partHash
    }
}

function Invoke-ModelDownloadWithFallback {
    param(
        [object[]]$Sources,
        [string]$TargetPath,
        [int64]$ExpectedSizeBytes,
        [string]$ExpectedSha256
    )

    $sourceList = @($Sources)
    if ($sourceList.Count -eq 0) {
        throw "Model manifest did not include url, downloadUrl, sourceUrl, source, downloadMirrors, or mirrors."
    }

    $failures = New-Object System.Collections.ArrayList
    for ($index = 0; $index -lt $sourceList.Count; $index++) {
        $source = $sourceList[$index]
        $sourceUrl = [string]$source.Url
        $sourceRole = [string]$source.Role
        Write-Host "       Source $($index + 1)/$($sourceList.Count) [$sourceRole]: $sourceUrl"

        try {
            if (Test-LocalSourceReference $sourceUrl) {
                $resolvedSourcePath = Resolve-LocalSourcePath $sourceUrl
                Invoke-LocalCopy -SourcePath $resolvedSourcePath -TargetPath $TargetPath
            } else {
                Invoke-RemoteDownload -SourceUrl $sourceUrl -TargetPath $TargetPath
            }

            $check = Test-HermesModelPart -PartPath $TargetPath -ExpectedSizeBytes $ExpectedSizeBytes -ExpectedSha256 $ExpectedSha256
            if ($check.Ok) {
                Write-Host "       Source succeeded."
                return [pscustomobject]@{
                    Source = $source
                    Hash   = $check.Hash
                }
            }

            throw $check.Message
        } catch {
            $message = $_.Exception.Message
            [void]$failures.Add("[$sourceRole] $sourceUrl : $message")
            Write-Warning "       Source failed: $message"

            if (Test-Path -LiteralPath $TargetPath) {
                $partInfo = Get-Item -LiteralPath $TargetPath
                if ($partInfo.Length -ge $ExpectedSizeBytes) {
                    Remove-Item -LiteralPath $TargetPath -Force
                    Write-Host "       Removed invalid complete part file before trying the next source."
                }
            }
        }
    }

    $detail = ($failures | ForEach-Object { " - $_" }) -join "`n"
    throw "All Hermes model download sources failed.`n$detail"
}

try {
    if (-not (Test-Path -LiteralPath $RootManifestPath)) {
        throw "Missing release-manifest.json in $UsbRoot"
    }

    Write-Host "正在检查授权..."
    if (-not $SkipLicenseCheck) {
        $license = Assert-CClawLicense -UsbRoot $UsbRoot -Purpose "hermes-model"
        Write-Host "  [通过] 授权：$($license.LicenseId) / $($license.Edition) / 更新有效期至 $($license.UpdatesUntil)"
    }

    Write-Host "正在读取升级源..."
    $rootManifestSource = Get-SourcePayload $RootManifestPath
    $rootManifest = $rootManifestSource.Text | ConvertFrom-Json

    $modelUpgrade = $rootManifest.modelUpgrade
    if ($null -eq $modelUpgrade -or ($modelUpgrade.PSObject.Properties.Name -contains "enabled" -and -not $modelUpgrade.enabled)) {
        Write-Host "[提示] release-manifest.json 中未启用 Hermes 模型升级。"
        exit 0
    }

    if ([string]::IsNullOrWhiteSpace($ManifestUrl)) {
        $ManifestUrl = Get-FirstPropertyValue $modelUpgrade @("manifestUrl", "channelManifestUrl", "modelManifestUrl")
    }

    Write-Host "Hermes 模型更新"
    Write-Host "USB 根目录：$UsbRoot"
    if ([string]::IsNullOrWhiteSpace($ManifestUrl)) {
        Write-Host "升级源    ：内置 release-manifest.json"
        $channelPayload = $rootManifestSource
        $channelManifest = $rootManifest
    } else {
        Write-Host "升级源    ：$ManifestUrl"
        $channelManifestSourceRef = Resolve-Reference $rootManifestSource.Source $ManifestUrl
        $channelPayload = Get-SourcePayload $channelManifestSourceRef
        $channelManifest = $channelPayload.Text | ConvertFrom-Json
    }

    $modelManifestRef = Get-ModelManifestUrl $channelManifest
    $modelPayload = $channelPayload
    if ($modelManifestRef) {
        $resolvedModelManifestRef = Resolve-Reference $channelPayload.Source $modelManifestRef
        $modelPayload = Get-SourcePayload $resolvedModelManifestRef
    }

    $modelManifest = $modelPayload.Text | ConvertFrom-Json
    $preferredModelId = Get-FirstPropertyValue $modelUpgrade @("modelId", "id")
    $modelEntry = Select-ModelEntry $modelManifest $preferredModelId

    $modelName = Get-FirstPropertyValue $modelEntry @("name", "id")
    $modelVersion = Get-FirstPropertyValue $modelEntry @("version")
    $downloadSources = Get-ModelDownloadSources $modelEntry
    $modelSha256 = Get-FirstPropertyValue $modelEntry @("sha256")
    $modelSizeBytes = Get-Int64Value $modelEntry @("sizeBytes", "size")
    $targetPath = Resolve-TargetPath $UsbRoot $modelEntry
    $safetyBytes = Get-Int64Value $modelUpgrade @("safetyBytes")
    if ($null -eq $safetyBytes) {
        $safetyBytes = 1073741824
    }

    if (@($downloadSources).Count -eq 0) {
        throw "Model manifest did not include url, downloadUrl, sourceUrl, source, downloadMirrors, or mirrors."
    }

    if ($null -eq $modelSizeBytes -or $modelSizeBytes -le 0) {
        throw "Model manifest did not include a valid sizeBytes/size value."
    }

    if ([string]::IsNullOrWhiteSpace($modelSha256)) {
        throw "Model manifest did not include sha256."
    }

    $resolvedTargetDir = Split-Path -Parent $targetPath
    if ([string]::IsNullOrWhiteSpace($resolvedTargetDir)) {
        throw "Cannot determine target directory for $targetPath"
    }

    $targetLeaf = [System.IO.Path]::GetFileName($targetPath)
    $partPath = Join-Path $ModelUpdateDir ($targetLeaf + ".part")
    $backupPath = Join-Path $resolvedTargetDir ($targetLeaf + ".previous")

    if (Test-Path -LiteralPath $targetPath) {
        $currentInfo = Get-Item -LiteralPath $targetPath
        if ($currentInfo.Length -eq $modelSizeBytes) {
            $currentHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $targetPath).Hash.ToUpperInvariant()
            if ($currentHash -eq $modelSha256.ToUpperInvariant()) {
                Write-Host "[完成] 当前 Hermes 模型已是最新版本，跳过下载。"
                if (Test-Path -LiteralPath $partPath) {
                    Remove-Item -LiteralPath $partPath -Force
                }
                exit 0
            }
        }
    }

    New-Item -ItemType Directory -Force -Path $ModelUpdateDir, $resolvedTargetDir | Out-Null

    $freeBytes = Get-DriveFreeBytes $UsbRoot
    $requiredBytes = [int64]$modelSizeBytes + [int64]$safetyBytes
    Write-Host "当前模型：$modelName"
    if ($modelVersion) {
        Write-Host "最新版本：$modelVersion"
    }
    Write-Host "安装目标：$targetPath"
    Write-Host "模型大小：$(Get-ReadableBytes $modelSizeBytes)"
    Write-Host "可用空间：$(Get-ReadableBytes $freeBytes)"
    Write-Host "至少需要：$(Get-ReadableBytes $requiredBytes)（模型 + 安全余量）"
    Write-Host "下载源数：$(@($downloadSources).Count)"
    Write-Host "提示：文件较大，请确认网络稳定、磁盘空间充足。"

    if ($freeBytes -lt $requiredBytes) {
        throw "Not enough free space on $UsbRoot. Need at least $(Get-ReadableBytes $requiredBytes), but only $(Get-ReadableBytes $freeBytes) is available."
    }

    Write-Host "[1/4] 正在下载 Hermes 模型到临时分片文件..."
    if (Test-Path -LiteralPath $partPath) {
        Write-Host "       继续使用已有分片：$partPath"
    } else {
        Write-Host "       分片文件：$partPath"
    }

    $downloadResult = Invoke-ModelDownloadWithFallback -Sources $downloadSources -TargetPath $partPath -ExpectedSizeBytes $modelSizeBytes -ExpectedSha256 $modelSha256

    $partInfo = Get-Item -LiteralPath $partPath
    if ($partInfo.Length -ne $modelSizeBytes) {
        throw "Downloaded part file size mismatch. Expected $modelSizeBytes bytes but got $($partInfo.Length) bytes."
    }

    Write-Host "[2/4] 正在校验 SHA256..."
    $partHash = $downloadResult.Hash
    if ([string]::IsNullOrWhiteSpace($partHash)) {
        $partHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $partPath).Hash.ToUpperInvariant()
    }
    if ($partHash -ne $modelSha256.ToUpperInvariant()) {
        throw "SHA256 mismatch for Hermes model. Expected $($modelSha256.ToUpperInvariant()) but got $partHash. The part file was kept for recovery."
    }

    Write-Host "[3/4] 正在替换目标模型..."
    $replacedExisting = $false
    if (Test-Path -LiteralPath $targetPath) {
        if (Test-Path -LiteralPath $backupPath) {
            Remove-Item -LiteralPath $backupPath -Force
        }
        Move-Item -LiteralPath $targetPath -Destination $backupPath
        $replacedExisting = $true
    }

    try {
        Move-Item -LiteralPath $partPath -Destination $targetPath
    } catch {
        if ($replacedExisting -and (Test-Path -LiteralPath $backupPath)) {
            Move-Item -LiteralPath $backupPath -Destination $targetPath -Force
        }
        throw
    }

    if ($replacedExisting -and (Test-Path -LiteralPath $backupPath)) {
        Remove-Item -LiteralPath $backupPath -Force
    }

    Write-Host "[4/4] Hermes 模型更新完成。"
    Write-Host "       已安装：$targetPath"
} catch {
    Write-Host ""
    Write-Warning "Hermes 模型更新失败。请联系售后并提供支持包，以上保留了具体错误详情。"
    throw
}
