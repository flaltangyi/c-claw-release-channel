param(
    [string]$UsbRoot = "",
    [switch]$Quiet
)

$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($UsbRoot)) {
    $UsbRoot = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot "..")).Path
} else {
    $UsbRoot = (Resolve-Path -LiteralPath $UsbRoot).Path
}

. (Join-Path $PSScriptRoot "CClaw-License.ps1")

$result = Test-CClawLicense -UsbRoot $UsbRoot

if ($Quiet) {
    if ($result.IsValid) {
        Write-Host "C-CLAW License: $($result.LicenseId) / $($result.Edition) / updates until $($result.UpdatesUntil)"
        exit 0
    }

    Write-Host "C-CLAW License: $($result.Status) - $($result.Message)"
    exit 2
}

Write-Host ""
Write-Host "========================================"
Write-Host "  C-CLAW License Status"
Write-Host "========================================"
Write-Host "Status       : $($result.Status)"
Write-Host "Message      : $($result.Message)"
Write-Host "License ID   : $($result.LicenseId)"
Write-Host "Edition      : $($result.Edition)"
Write-Host "Channel      : $($result.Channel)"
Write-Host "Issued At    : $($result.IssuedAt)"
Write-Host "Support Until: $($result.SupportUntil) (active: $($result.SupportActive))"
Write-Host "Updates Until: $($result.UpdatesUntil) (active: $($result.UpdatesActive))"
Write-Host "Features     : $($result.Features -join ', ')"
Write-Host "License File : $($result.LicensePath)"
Write-Host ""

if ($result.IsValid) {
    exit 0
}

exit 2
