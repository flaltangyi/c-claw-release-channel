#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=portable/Linux-Support.sh
source "$SCRIPT_DIR/Linux-Support.sh"

timeout_seconds="${1:-300}"
probe_interval_seconds="${UCLAW_VALIDATE_INTERVAL_SECONDS:-1}"
log_dir="$DATA_DIR/logs"
mkdir -p "$log_dir"
log_file="$log_dir/linux-gateway-validate-$(date +%Y%m%d_%H%M%S).log"

runner_pid=""
run_pids=""
gateway_ready=0
config_ready=0
gateway_port=""

uclaw_collect_descendants() {
    local root="$1"
    local child
    if [[ -z "$root" ]]; then
        return 0
    fi
    printf '%s\n' "$root"
    for child in $(pgrep -P "$root" 2>/dev/null || true); do
        uclaw_collect_descendants "$child"
    done
}

uclaw_remember_run_pids() {
    if [[ -n "$runner_pid" ]]; then
        run_pids="$(printf '%s\n%s\n' "$run_pids" "$(uclaw_collect_descendants "$runner_pid" 2>/dev/null || true)" | sed '/^$/d' | sort -n -u)"
    fi
}

uclaw_read_gateway_port() {
    sed -n 's/.*gateway: http:\/\/127\.0\.0\.1:\([0-9][0-9]*\)\/.*/\1/p' "$log_file" 2>/dev/null | tail -n 1
}

uclaw_port_is_listening() {
    local port="$1"
    [[ -n "$port" ]] && ss -tln 2>/dev/null | awk -v needle=":${port}" '$4 ~ needle "$" {found=1} END {exit found ? 0 : 1}'
}

cleanup_runner() {
    uclaw_remember_run_pids
    if [[ -n "$runner_pid" ]] && kill -0 "$runner_pid" 2>/dev/null; then
        kill "$runner_pid" 2>/dev/null || true
    fi
    if [[ -n "$runner_pid" ]]; then
        wait "$runner_pid" 2>/dev/null || true
    fi
    sleep 1
    uclaw_remember_run_pids
    local pid
    for pid in $run_pids; do
        if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
            kill "$pid" 2>/dev/null || true
        fi
    done
}

trap cleanup_runner EXIT

printf 'Starting Linux validation run...\n'
printf '  log: %s\n' "$log_file"

UCLAW_NO_BROWSER=1 timeout "${timeout_seconds}s" bash "$SCRIPT_DIR/Start-OpenClaw-Hermes.sh" >"$log_file" 2>&1 &
runner_pid="$!"

deadline=$((SECONDS + timeout_seconds))
while (( SECONDS < deadline )); do
    uclaw_remember_run_pids
    if [[ -z "$gateway_port" ]]; then
        gateway_port="$(uclaw_read_gateway_port)"
    fi
    if [[ "$config_ready" -eq 0 ]] && curl -fsS --max-time 2 http://127.0.0.1:18788/ >/dev/null 2>&1; then
        config_ready=1
    fi
    if [[ "$gateway_ready" -eq 0 ]] && uclaw_port_is_listening "$gateway_port"; then
        gateway_ready=1
    fi
    if [[ "$gateway_ready" -eq 1 && "$config_ready" -eq 1 ]]; then
        break
    fi
    if ! kill -0 "$runner_pid" 2>/dev/null; then
        break
    fi
    sleep "$probe_interval_seconds"
done

uclaw_remember_run_pids
cleanup_runner
trap - EXIT

leftovers=""
for pid in $run_pids; do
    if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
        process_line="$(ps -p "$pid" -o pid=,args= 2>/dev/null || true)"
        if [[ -n "$process_line" ]]; then
            leftovers+="${process_line}"$'\n'
        fi
    fi
done
if [[ -n "$leftovers" ]]; then
    leftover_state=1
else
    leftover_state=0
fi

if [[ "$gateway_ready" -eq 1 && "$config_ready" -eq 1 && "$leftover_state" -eq 0 ]]; then
    status="PASS"
else
    status="BLOCKED"
fi

printf 'STATUS=%s\n' "$status"
printf 'GATEWAY_READY=%s\n' "$gateway_ready"
printf 'CONFIG_READY=%s\n' "$config_ready"
printf 'GATEWAY_PORT=%s\n' "${gateway_port:-unknown}"
printf 'LEFTOVER_PROCESSES=%s\n' "$leftover_state"
printf 'LOG=%s\n' "$log_file"

if [[ -n "$leftovers" ]]; then
    printf '%s\n' "$leftovers"
fi

printf '\nLast 40 log lines:\n'
tail -n 40 "$log_file" || true

if [[ "$status" != "PASS" ]]; then
    exit 1
fi
