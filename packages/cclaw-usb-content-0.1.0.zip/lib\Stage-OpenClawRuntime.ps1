param(
    [Parameter(Mandatory = $true)]
    [string]$UsbRoot,

    [string]$CacheRoot,

    [string]$EnvFile,

    [switch]$Force
)

$ErrorActionPreference = "Stop"

function Write-Status {
    param([string]$Message)
    [Console]::Error.WriteLine($Message)
}

function Get-TextFileValue {
    param([string]$Path, [string]$Fallback)
    if (Test-Path -LiteralPath $Path) {
        $value = (Get-Content -LiteralPath $Path -Raw -ErrorAction Stop).Trim()
        if ($value) { return $value }
    }
    return $Fallback
}

function Get-SafeName {
    param([string]$Value)
    $safe = $Value -replace '[^A-Za-z0-9._-]', '-'
    if ([string]::IsNullOrWhiteSpace($safe)) { return "current" }
    return $safe
}

function Assert-ChildPath {
    param([string]$Parent, [string]$Child)
    $parentFull = [System.IO.Path]::GetFullPath($Parent).TrimEnd('\') + '\'
    $childFull = [System.IO.Path]::GetFullPath($Child)
    if (-not $childFull.StartsWith($parentFull, [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Refusing to mirror outside cache root: $childFull"
    }
}

function Invoke-RobocopyMirror {
    param(
        [string]$Source,
        [string]$Destination,
        [string]$Label
    )

    if (-not (Test-Path -LiteralPath $Source)) {
        Write-Status "  [SKIP] $Label not found."
        return
    }

    New-Item -ItemType Directory -Force -Path $Destination | Out-Null
    Assert-ChildPath -Parent $script:CacheRootFull -Child $Destination

    Write-Status "  [CACHE] $Label"
    $args = @(
        $Source,
        $Destination,
        "/MIR",
        "/MT:16",
        "/R:1",
        "/W:1",
        "/NFL",
        "/NDL",
        "/NP",
        "/NJH",
        "/NJS",
        "/XJ",
        "/XD",
        ".openclaw-npm-cache"
    )
    & robocopy @args | Out-Null
    $code = $LASTEXITCODE
    if ($code -ge 8) {
        throw "Robocopy failed for $Label with exit code $code"
    }
}

$usbRootFull = (Resolve-Path -LiteralPath $UsbRoot).Path.TrimEnd('\')
$sourceApp = Join-Path $usbRootFull "app"
$sourceCore = Join-Path $sourceApp "core"
$sourceOpenClaw = Join-Path $sourceCore "node_modules\openclaw\openclaw.mjs"

if (-not (Test-Path -LiteralPath $sourceOpenClaw)) {
    throw "OpenClaw runtime is incomplete. Missing: $sourceOpenClaw"
}

if (-not $CacheRoot) {
    if (-not $env:LOCALAPPDATA) {
        throw "LOCALAPPDATA is not set; cannot create local runtime cache."
    }
    $CacheRoot = Join-Path $env:LOCALAPPDATA "C-CLAW\runtime-cache"
}

$script:CacheRootFull = [System.IO.Path]::GetFullPath($CacheRoot)
New-Item -ItemType Directory -Force -Path $script:CacheRootFull | Out-Null

$cclawVersion = Get-TextFileValue -Path (Join-Path $usbRootFull "C-CLAW_VERSION") -Fallback "current"
$openclawVersion = Get-TextFileValue -Path (Join-Path $usbRootFull "OPENCLAW_VERSION") -Fallback "openclaw"
$cacheName = "c-claw-" + (Get-SafeName "$cclawVersion-$openclawVersion")
$targetRoot = Join-Path $script:CacheRootFull $cacheName
$targetApp = Join-Path $targetRoot "app"

Assert-ChildPath -Parent $script:CacheRootFull -Child $targetRoot
New-Item -ItemType Directory -Force -Path $targetApp | Out-Null

Write-Status "Preparing local OpenClaw runtime cache:"
Write-Status "  Source: $sourceApp"
Write-Status "  Target: $targetApp"
Write-Status "  Large model files stay on the USB drive."

Invoke-RobocopyMirror -Source (Join-Path $sourceApp "runtime") -Destination (Join-Path $targetApp "runtime") -Label "Node runtime"
Invoke-RobocopyMirror -Source $sourceCore -Destination (Join-Path $targetApp "core") -Label "OpenClaw core"
Invoke-RobocopyMirror -Source (Join-Path $sourceApp "plugin-runtime-deps") -Destination (Join-Path $targetApp "plugin-runtime-deps") -Label "plugin runtime deps"
Invoke-RobocopyMirror -Source (Join-Path $sourceApp "extensions") -Destination (Join-Path $targetApp "extensions") -Label "extensions"

$manifest = [ordered]@{
    generatedAt = (Get-Date).ToString("o")
    usbRoot = $usbRootFull
    cacheRoot = $targetRoot
    cclawVersion = $cclawVersion
    openclawVersion = $openclawVersion
    force = [bool]$Force
}
$manifest | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $targetRoot "runtime-cache-manifest.json") -Encoding UTF8

$envLines = @(
    "set ""C_CLAW_RUNTIME_ROOT=$targetRoot"""
    "set ""C_CLAW_RUNTIME_APP_DIR=$targetApp"""
    "set ""C_CLAW_RUNTIME_NODE_DIR=$(Join-Path $targetApp 'runtime\node-win-x64')"""
)

if ($EnvFile) {
    $envFileParent = Split-Path -Parent $EnvFile
    if ($envFileParent) {
        New-Item -ItemType Directory -Force -Path $envFileParent | Out-Null
    }
    $envLines | Set-Content -LiteralPath $EnvFile -Encoding ASCII
}

$envLines | ForEach-Object { [Console]::Out.WriteLine($_) }
exit 0
