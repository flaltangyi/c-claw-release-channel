#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

case "${1:-}" in
    --support|support)
        exec "$SCRIPT_DIR/Linux-Support.sh" status
        ;;
    --hermes|hermes|model)
        exec "$SCRIPT_DIR/Start-Hermes-Local.sh"
        ;;
    *)
        exec "$SCRIPT_DIR/Start-OpenClaw-Hermes.sh"
        ;;
esac
