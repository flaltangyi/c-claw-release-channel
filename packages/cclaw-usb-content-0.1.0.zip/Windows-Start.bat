@echo off
title C-CLAW - Windows Start

echo.
echo   ========================================
echo     C-CLAW - Windows Start
echo   ========================================
echo.
echo   Keep this window open while using C-CLAW.
echo   Closing this window stops the local assistant service.
echo.

set "UCLAW_DIR=%~dp0"
set "APP_DIR=%UCLAW_DIR%app"

REM Migration shim: rename old core-win to core for existing USB users.
if exist "%APP_DIR%\core-win" if not exist "%APP_DIR%\core" ren "%APP_DIR%\core-win" core

set "CORE_DIR=%APP_DIR%\core"
set "DATA_DIR=%UCLAW_DIR%data"
set "STATE_DIR=%DATA_DIR%\.openclaw"
set "NODE_DIR=%APP_DIR%\runtime\node-win-x64"
set "NODE_BIN=%NODE_DIR%\node.exe"
set "NPM_BIN=%NODE_DIR%\npm.cmd"

set "OPENCLAW_HOME=%DATA_DIR%"
set "OPENCLAW_STATE_DIR=%STATE_DIR%"
set "OPENCLAW_CONFIG_PATH=%STATE_DIR%\openclaw.json"

if not exist "%NODE_BIN%" (
    echo   [ERROR] Missing runtime: app\runtime\node-win-x64
    echo   The USB package may be incomplete or quarantined by security software.
    echo   Run Windows-Support.bat and send the support bundle to support.
    pause
    exit /b 1
)

for /f "tokens=*" %%v in ('"%NODE_BIN%" --version') do set NODE_VER=%%v
echo   Node.js: %NODE_VER%
echo.

set "PATH=%NODE_DIR%;%NODE_DIR%\node_modules\.bin;%PATH%"

if not exist "%DATA_DIR%" mkdir "%DATA_DIR%"
if not exist "%STATE_DIR%" mkdir "%STATE_DIR%"
if not exist "%DATA_DIR%\memory" mkdir "%DATA_DIR%\memory"
if not exist "%DATA_DIR%\backups" mkdir "%DATA_DIR%\backups"
if not exist "%DATA_DIR%\logs" mkdir "%DATA_DIR%\logs"

set "OPENCLAW_REPAIR_SCRIPT=%UCLAW_DIR%support\Repair-OpenClawGateway.ps1"
if exist "%OPENCLAW_REPAIR_SCRIPT%" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%OPENCLAW_REPAIR_SCRIPT%" -UsbRoot "%UCLAW_DIR%" -PortStart 18789 -PortEnd 18799
    set "OPENCLAW_REPAIR_EXIT=%ERRORLEVEL%"
    if "%OPENCLAW_REPAIR_EXIT%"=="10" (
        echo.
        echo   Existing OpenClaw gateway is healthy. Browser opened.
        echo   Keep the existing gateway window open while using C-CLAW.
        pause
        exit /b 0
    )
    if not "%OPENCLAW_REPAIR_EXIT%"=="0" (
        echo   [WARN] Existing gateway check failed. Continuing startup.
        echo.
    )
)

if not exist "%STATE_DIR%\openclaw.json" (
    if exist "%DATA_DIR%\config.json" (
        echo   Migrating legacy config...
        copy "%DATA_DIR%\config.json" "%STATE_DIR%\openclaw.json" >nul
        echo   Config migrated.
    ) else (
        echo   First run - creating default config...
        (echo {"gateway":{"mode":"local","auth":{"token":"uclaw"}}})>"%STATE_DIR%\openclaw.json"
        echo   Config created.
    )
    echo.
)

if not exist "%CORE_DIR%\node_modules" (
    echo   ========================================
    echo   [WARN] node_modules not found
    echo   ========================================
    echo   This release should ship with dependencies pre-installed.
    echo   Falling back to npm install. USB drives may take 20+ minutes.
    echo.
    echo   TIP: Re-copy a full C-CLAW release package if this repeats.
    echo.
    cd /d "%CORE_DIR%"
    call "%NPM_BIN%" install --registry=https://registry.npmmirror.com --ignore-scripts --no-audit --no-fund --omit=dev
    echo.
    echo   Dependencies installed.
    echo.
)

echo   Binding local device fingerprint...
set "UCLAW_APP_ROOT=%UCLAW_DIR%"
set "C_CLAW_LOCAL_ONLY=1"
"%NODE_BIN%" "%UCLAW_DIR%lib\bootstrap-xiapan.mjs" "%STATE_DIR%\openclaw.json"
echo.

set "VERSION_FILE=%UCLAW_DIR%OPENCLAW_VERSION"
if not exist "%VERSION_FILE%" set "VERSION_FILE=%UCLAW_DIR%..\OPENCLAW_VERSION"
if exist "%VERSION_FILE%" (
    start /B "" "%NODE_BIN%" "%UCLAW_DIR%lib\check-update.mjs" "%VERSION_FILE%" "%STATE_DIR%" >nul 2>&1
)

set "WECHAT_PLUGIN_SRC=%APP_DIR%\extensions\openclaw-weixin"
set "WECHAT_PLUGIN_DST=%USERPROFILE%\.openclaw\extensions\openclaw-weixin"
if exist "%WECHAT_PLUGIN_SRC%\openclaw.plugin.json" (
    if not exist "%WECHAT_PLUGIN_DST%\openclaw.plugin.json" (
        echo   Installing WeChat plugin...
        mkdir "%USERPROFILE%\.openclaw\extensions" 2>nul
        xcopy /s /e /q /y "%WECHAT_PLUGIN_SRC%" "%WECHAT_PLUGIN_DST%\" >nul
        echo   WeChat plugin installed.
        echo.
    )
)

set PORT=18789
:check_port
netstat -an | findstr ":%PORT% " | findstr "LISTENING" >nul 2>&1
if %errorlevel%==0 (
    echo   Port %PORT% in use, trying next...
    set /a PORT+=1
    if %PORT% gtr 18799 (
        echo   No available port in range 18789-18799.
        pause
        exit /b 1
    )
    goto :check_port
)

echo   Starting OpenClaw on port %PORT%...
echo.

echo   Starting Config Center on port 18788...
set "CONFIG_SERVER=%UCLAW_DIR%config-server"
start /B "" "%NODE_BIN%" "%CONFIG_SERVER%\server.js" >nul 2>&1

echo   Config Center opens first. The assistant page opens after OpenClaw is ready.
start /B "" powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Sleep -Seconds 2; Start-Process 'http://127.0.0.1:18788/'"
start /B "" powershell -NoProfile -ExecutionPolicy Bypass -Command "$u='http://127.0.0.1:%PORT%/'; for($i=1; $i -le 180; $i++){ try { Invoke-WebRequest -UseBasicParsing -Uri $u -TimeoutSec 2 | Out-Null; Start-Process ($u + '#token=uclaw'); exit 0 } catch { Start-Sleep -Seconds 1 } }; Write-Host '  [WARN] OpenClaw browser did not open in time'; exit 1"

echo   Browsers scheduled. Starting OpenClaw Gateway on port %PORT%...
echo.
echo   Keep this window open while using C-CLAW.
echo.

cd /d "%CORE_DIR%"
set "OPENCLAW_MJS=%CORE_DIR%\node_modules\openclaw\openclaw.mjs"
set "OPENCLAW_OUT_LOG=%DATA_DIR%\logs\openclaw-gateway.out.log"
set "OPENCLAW_ERR_LOG=%DATA_DIR%\logs\openclaw-gateway.err.log"
echo   OpenClaw stdout log: %OPENCLAW_OUT_LOG%
echo   OpenClaw stderr log: %OPENCLAW_ERR_LOG%
echo.
>>"%OPENCLAW_OUT_LOG%" echo.
>>"%OPENCLAW_OUT_LOG%" echo ==== C-CLAW OpenClaw start %DATE% %TIME% port %PORT% ====
>>"%OPENCLAW_ERR_LOG%" echo.
>>"%OPENCLAW_ERR_LOG%" echo ==== C-CLAW OpenClaw start %DATE% %TIME% port %PORT% ====
"%NODE_BIN%" "%OPENCLAW_MJS%" gateway run --allow-unconfigured --force --port %PORT% 1>>"%OPENCLAW_OUT_LOG%" 2>>"%OPENCLAW_ERR_LOG%"

echo.
echo   OpenClaw stopped.
pause
